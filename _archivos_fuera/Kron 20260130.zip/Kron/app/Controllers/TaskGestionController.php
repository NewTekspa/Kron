<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Models\Task;
use App\Models\Team;
use App\Models\User;

class TaskGestionController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();

        $user = Auth::user();
        $roleName = strtolower(trim(Auth::roleName() ?? ''));
        $isAdmin = Auth::isAdmin();

        if (! $isAdmin && ! in_array($roleName, ['jefe', 'subgerente'], true)) {
            http_response_code(403);
            echo 'Acceso denegado.';
            return;
        }

        $userId = (int) ($user['id'] ?? 0);
        $monthStart = (new \DateTimeImmutable('first day of this month'))->format('Y-m-d');
        $monthEnd = (new \DateTimeImmutable('today'))->format('Y-m-d');

        $teams = Team::visibleTeamsForRole($userId, $roleName, $isAdmin);
        $teamIds = array_map(static fn ($team) => (int) $team['id'], $teams);
        $teamMembers = Team::membersForTeams($teamIds);

        if ($isAdmin) {
            $users = User::allWithRole();
            $visibleUserIds = array_map(static fn ($item) => (int) $item['id'], $users);
        } else {
            $visibleUserIds = Team::visibleUserIdsForRole($userId, $roleName);
            $users = User::allWithRoleByIds($visibleUserIds);
        }

        $taskTotals = Task::countsByUserIdsInRange($visibleUserIds, $monthStart, $monthEnd);
        $taskCompleted = Task::completedCountsByUserIdsInRange($visibleUserIds, $monthStart, $monthEnd);
        $hoursTotals = Task::hoursTotalsByUserIdsInRange($visibleUserIds, $monthStart, $monthEnd);

        $collaboratorStats = [];
        foreach ($users as $item) {
            $itemUserId = (int) $item['id'];
            $total = (int) ($taskTotals[$itemUserId] ?? 0);
            $completed = (int) ($taskCompleted[$itemUserId] ?? 0);
            $hours = (float) ($hoursTotals[$itemUserId] ?? 0);
            $rate = $total > 0 ? round(($completed / $total) * 100, 1) : 0;
            $collaboratorStats[] = [
                'id' => $itemUserId,
                'nombre' => $item['nombre'],
                'rol' => $item['rol_nombre'] ?? '',
                'total' => $total,
                'terminadas' => $completed,
                'horas' => $hours,
                'cumplimiento' => $rate,
            ];
        }

        $teamStats = [];
        foreach ($teams as $team) {
            $teamId = (int) $team['id'];
            $members = $teamMembers[$teamId] ?? [];
            $memberIds = array_map(static fn ($member) => (int) $member['id'], $members);

            $total = 0;
            $completed = 0;
            $hours = 0.0;
            foreach ($memberIds as $memberId) {
                $total += (int) ($taskTotals[$memberId] ?? 0);
                $completed += (int) ($taskCompleted[$memberId] ?? 0);
                $hours += (float) ($hoursTotals[$memberId] ?? 0);
            }

            $rate = $total > 0 ? round(($completed / $total) * 100, 1) : 0;
            $teamStats[] = [
                'id' => $teamId,
                'nombre' => $team['nombre'],
                'colaboradores' => count($members),
                'total' => $total,
                'terminadas' => $completed,
                'horas' => $hours,
                'cumplimiento' => $rate,
            ];
        }

        $totalTasks = array_sum($taskTotals);
        $totalCompleted = array_sum($taskCompleted);
        $totalHours = array_sum($hoursTotals);
        $completionRate = $totalTasks > 0 ? round(($totalCompleted / $totalTasks) * 100, 1) : 0;

        $this->view('tasks/gestion', [
            'title' => 'Gestion',
            'teams' => $teams,
            'teamStats' => $teamStats,
            'collaboratorStats' => $collaboratorStats,
            'monthLabel' => (new \DateTimeImmutable($monthStart))->format('m/Y'),
            'totalTasks' => $totalTasks,
            'totalCompleted' => $totalCompleted,
            'totalHours' => $totalHours,
            'completionRate' => $completionRate,
        ]);
    }
}
