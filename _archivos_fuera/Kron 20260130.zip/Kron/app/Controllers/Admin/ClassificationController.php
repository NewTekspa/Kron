<?php

namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\TaskClassification;

class ClassificationController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $classifications = TaskClassification::all();
        $error = trim($_GET['error'] ?? '');

        $this->view('admin/classifications/index', [
            'title' => 'Categorias',
            'classifications' => $classifications,
            'error' => $error !== '' ? $error : null,
        ]);
    }

    public function store(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $nombre = trim($_POST['nombre'] ?? '');
        if ($nombre === '') {
            header('Location: /admin/categorias?error=Nombre+incompleto');
            exit;
        }

        TaskClassification::create($nombre);

        header('Location: /admin/categorias');
        exit;
    }

    public function update(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $id = (int) ($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        if ($id === 0 || $nombre === '') {
            header('Location: /admin/categorias?error=Datos+incompletos');
            exit;
        }

        TaskClassification::updateName($id, $nombre);

        header('Location: /admin/categorias');
        exit;
    }

    public function delete(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $id = (int) ($_POST['id'] ?? 0);
        if ($id === 0) {
            header('Location: /admin/categorias?error=Categoria+no+valida');
            exit;
        }

        TaskClassification::delete($id);

        header('Location: /admin/categorias');
        exit;
    }
}
