<?php

namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\Team;
use App\Models\Role;

class TeamController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $teams = Team::all();
        $teamIds = array_map(fn ($team) => (int) $team['id'], $teams);
        $membersByTeam = Team::membersForTeams($teamIds);
        $error = trim($_GET['error'] ?? '');

        $this->view('admin/teams/index', [
            'title' => 'Equipos',
            'teams' => $teams,
            'membersByTeam' => $membersByTeam,
            'error' => $error !== '' ? $error : null,
        ]);
    }

    public function store(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $nombre = trim($_POST['nombre'] ?? '');
        $subgerenteId = (int) ($_POST['subgerente_id'] ?? 0);
        $jefeId = (int) ($_POST['jefe_id'] ?? 0);

        if ($nombre === '' || $subgerenteId === 0 || $jefeId === 0 || $subgerenteId === $jefeId) {
            header('Location: /admin/equipos?error=Datos+incompletos');
            exit;
        }

        $subgerenteRole = Role::getUserRoleName($subgerenteId);
        $jefeRole = Role::getUserRoleName($jefeId);

        if ($subgerenteRole !== 'subgerente' || $jefeRole !== 'jefe') {
            header('Location: /admin/equipos?error=Relacion+no+valida');
            exit;
        }

        Team::create($nombre, $subgerenteId, $jefeId);

        header('Location: /admin/equipos');
        exit;
    }

    public function assignMember(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $teamId = (int) ($_POST['team_id'] ?? 0);
        $colaboradorId = (int) ($_POST['colaborador_id'] ?? 0);

        if ($teamId === 0 || $colaboradorId === 0 || ! Team::exists($teamId)) {
            header('Location: /admin/equipos?error=Datos+incompletos');
            exit;
        }

        $colaboradorRole = Role::getUserRoleName($colaboradorId);
        if ($colaboradorRole !== 'colaborador') {
            header('Location: /admin/equipos?error=Relacion+no+valida');
            exit;
        }

        Team::assignMember($teamId, $colaboradorId);

        header('Location: /admin/equipos');
        exit;
    }

    public function removeMember(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $teamId = (int) ($_POST['team_id'] ?? 0);
        $colaboradorId = (int) ($_POST['colaborador_id'] ?? 0);

        if ($teamId === 0 || $colaboradorId === 0) {
            header('Location: /admin/equipos?error=Datos+incompletos');
            exit;
        }

        Team::removeMember($teamId, $colaboradorId);

        header('Location: /admin/equipos');
        exit;
    }

    public function search(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $term = trim($_GET['q'] ?? '');
        $limit = (int) ($_GET['limit'] ?? 15);

        if (strlen($term) < 2) {
            header('Content-Type: application/json');
            echo json_encode([]);
            return;
        }

        $results = Team::searchByName($term, $limit);

        header('Content-Type: application/json');
        echo json_encode($results);
    }

    public function show(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $id = (int) ($_GET['id'] ?? 0);
        if ($id <= 0) {
            http_response_code(404);
            echo 'Equipo no encontrado.';
            return;
        }

        $team = Team::findWithLeaders($id);
        if (! $team) {
            http_response_code(404);
            echo 'Equipo no encontrado.';
            return;
        }

        $members = Team::members($id);

        $this->view('admin/teams/show', [
            'title' => 'Detalle de equipo',
            'team' => $team,
            'members' => $members,
        ]);
    }

    public function delete(): void
    {
        $this->requireLogin();
        $this->requireAdmin();

        $id = (int) ($_POST['id'] ?? 0);
        if ($id > 0) {
            Team::delete($id);
        }

        header('Location: /admin/equipos');
        exit;
    }
}
