<?php
/** @var string $title */
/** @var array $teams */
/** @var array $membersByTeam */
/** @var string|null $error */
ob_start();
?>
<div class="page-header">
    <h1>Equipos</h1>
</div>
<?php if (! empty($error)): ?>
    <div class="alert"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="form-grid">
    <form method="post" action="/admin/equipos/crear" class="form">
        <h2>Crear equipo</h2>
        <label>Nombre del equipo</label>
        <input type="text" name="nombre" required>

        <div class="autocomplete">
            <label>Subgerente</label>
            <input type="text" name="subgerente_label" data-source="users" data-role="subgerente" autocomplete="off" required>
            <input type="hidden" name="subgerente_id" value="">
            <div class="autocomplete-results"></div>
        </div>

        <div class="autocomplete">
            <label>Jefe</label>
            <input type="text" name="jefe_label" data-source="users" data-role="jefe" autocomplete="off" required>
            <input type="hidden" name="jefe_id" value="">
            <div class="autocomplete-results"></div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">Guardar equipo</button>
        </div>
    </form>

    <form method="post" action="/admin/equipos/asignar-colaborador" class="form">
        <h2>Asignar colaborador</h2>
        <div class="autocomplete">
            <label>Equipo</label>
            <input type="text" name="team_label" data-source="teams" autocomplete="off" required>
            <input type="hidden" name="team_id" value="">
            <div class="autocomplete-results"></div>
        </div>

        <div class="autocomplete">
            <label>Colaborador</label>
            <input type="text" name="colaborador_label" data-source="users" data-role="colaborador" autocomplete="off" required>
            <input type="hidden" name="colaborador_id" value="">
            <div class="autocomplete-results"></div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">Asignar</button>
        </div>
    </form>
</div>

<table class="table">
    <caption class="table-filter">
        <div class="filter-bar">
            <label for="teamFilter">Filtrar equipos</label>
            <input type="text" id="teamFilter" placeholder="Buscar por equipo, jefe, subgerente o colaborador" autocomplete="off">
        </div>
    </caption>
    <thead>
        <tr>
            <th>Equipo</th>
            <th>Subgerente</th>
            <th>Jefe</th>
            <th>Colaboradores</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($teams as $team): ?>
            <?php $members = $membersByTeam[(int) $team['id']] ?? []; ?>
            <tr>
                <td><?= htmlspecialchars($team['nombre']) ?></td>
                <td><?= htmlspecialchars($team['subgerente_nombre']) ?></td>
                <td><?= htmlspecialchars($team['jefe_nombre']) ?></td>
                <td>
                    <?php if (! empty($members)): ?>
                        <div class="team-members">
                            <?php foreach ($members as $member): ?>
                                <div class="team-member">
                                    <span><?= htmlspecialchars($member['nombre']) ?> (<?= htmlspecialchars($member['email']) ?>)</span>
                                    <form method="post" action="/admin/equipos/remover-colaborador" class="inline">
                                        <input type="hidden" name="team_id" value="<?= (int) $team['id'] ?>">
                                        <input type="hidden" name="colaborador_id" value="<?= (int) $member['id'] ?>">
                                        <button type="submit" class="btn btn-danger btn-small">Quitar</button>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <span class="muted">Sin colaboradores</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="/admin/equipos/detalle?id=<?= (int) $team['id'] ?>" class="btn btn-secondary btn-small">Detalle</a>
                    <form method="post" action="/admin/equipos/eliminar" class="inline" onsubmit="return confirm('Eliminar equipo y sus miembros?');">
                        <input type="hidden" name="id" value="<?= (int) $team['id'] ?>">
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<script>
const teamSearch = (() => {
    const debounce = (fn, wait = 300) => {
        let t;
        return (...args) => {
            clearTimeout(t);
            t = setTimeout(() => fn(...args), wait);
        };
    };

    const renderResults = (container, items, input, hidden, formatter) => {
        container.innerHTML = '';
        if (!items.length) {
            return;
        }
        items.forEach((item) => {
            const row = document.createElement('div');
            row.className = 'autocomplete-item';
            row.textContent = formatter(item);
            row.addEventListener('click', () => {
                input.value = formatter(item);
                hidden.value = item.id;
                container.innerHTML = '';
            });
            container.appendChild(row);
        });
    };

    const fetchUsers = async (term, role, limit = 15) => {
        const params = new URLSearchParams({ q: term, role, limit });
        const res = await fetch(`/admin/usuarios/buscar?${params.toString()}`);
        if (!res.ok) {
            return [];
        }
        return res.json();
    };

    const fetchTeams = async (term, limit = 15) => {
        const params = new URLSearchParams({ q: term, limit });
        const res = await fetch(`/admin/equipos/buscar?${params.toString()}`);
        if (!res.ok) {
            return [];
        }
        return res.json();
    };

    const initField = (wrapper) => {
        const input = wrapper.querySelector('input[type="text"]');
        const hidden = wrapper.querySelector('input[type="hidden"]');
        const results = wrapper.querySelector('.autocomplete-results');
        const source = input.dataset.source;
        const role = input.dataset.role || '';

        const handle = debounce(async () => {
            const term = input.value.trim();
            hidden.value = '';
            if (term.length < 2) {
                results.innerHTML = '';
                return;
            }

            if (source === 'teams') {
                const items = await fetchTeams(term);
                renderResults(results, items, input, hidden, (item) => item.nombre);
                return;
            }

            const items = await fetchUsers(term, role);
            renderResults(results, items, input, hidden, (item) => `${item.nombre} (${item.email})`);
        });

        input.addEventListener('input', handle);
        document.addEventListener('click', (event) => {
            if (!wrapper.contains(event.target)) {
                results.innerHTML = '';
            }
        });
    };

    const guardForm = (form, fields) => {
        if (!form) {
            return;
        }
        form.addEventListener('submit', (event) => {
            for (const name of fields) {
                if (!form.querySelector(`input[name="${name}"]`)?.value) {
                    event.preventDefault();
                    alert('Selecciona valores desde la lista.');
                    return;
                }
            }
        });
    };

    const initFilter = () => {
        const input = document.getElementById('teamFilter');
        if (!input) {
            return;
        }
        const rows = Array.from(document.querySelectorAll('table tbody tr'));
        const handle = debounce(() => {
            const term = input.value.trim().toLowerCase();
            rows.forEach((row) => {
                const haystack = row.textContent.toLowerCase();
                row.style.display = haystack.includes(term) ? '' : 'none';
            });
        }, 150);
        input.addEventListener('input', handle);
    };

    return {
        init() {
            document.querySelectorAll('.autocomplete').forEach(initField);
            guardForm(document.querySelector('form[action="/admin/equipos/crear"]'), ['subgerente_id', 'jefe_id']);
            guardForm(document.querySelector('form[action="/admin/equipos/asignar-colaborador"]'), ['team_id', 'colaborador_id']);
            initFilter();
        },
    };
})();

teamSearch.init();
</script>
<?php
$content = ob_get_clean();
require __DIR__ . '/../../layouts/main.php';
