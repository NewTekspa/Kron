<?php
/** @var string $title */
/** @var array $users */
/** @var array|null $authUser */
/** @var bool $isAdmin */
ob_start();
$formatDate = function (?string $value): string {
    if (! $value) {
        return '-';
    }
    $timestamp = strtotime($value);
    return $timestamp ? date('d-m-Y', $timestamp) : $value;
};
?>
<div class="page-header">
    <h1>Usuarios</h1>
    <?php if ($isAdmin): ?>
        <a class="btn" href="/admin/usuarios/nuevo">Nuevo usuario</a>
    <?php endif; ?>
</div>
<?php if (! empty($users)): ?>
<table class="table">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Estado</th>
            <th>Fecha ingreso</th>
            <th>Rol</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= htmlspecialchars($user['nombre']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['estado']) ?></td>
                <td><?= htmlspecialchars($formatDate($user['fecha_ingreso'] ?? null)) ?></td>
                <td><?= htmlspecialchars($user['rol_nombre'] ?? '-') ?></td>
                <td>
                    <?php if ($isAdmin || $authUser): ?>
                        <a class="btn btn-secondary" href="/admin/usuarios/editar?id=<?= (int) $user['id'] ?>">Editar</a>
                    <?php endif; ?>
                    <?php if ($isAdmin && $user['estado'] === 'activo'): ?>
                        <form method="post" action="/admin/usuarios/desactivar" class="inline">
                            <input type="hidden" name="id" value="<?= (int) $user['id'] ?>">
                            <button type="submit" class="btn btn-danger">Desactivar</button>
                        </form>
                    <?php endif; ?>
                    <?php if ($isAdmin): ?>
                        <form method="post" action="/admin/usuarios/eliminar" class="inline" onsubmit="return confirm('Esta accion elimina al usuario. ¿Continuar?');">
                            <input type="hidden" name="id" value="<?= (int) $user['id'] ?>">
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
<p>No hay usuarios registrados.</p>
<?php endif; ?>
<?php
$content = ob_get_clean();
require __DIR__ . '/../../layouts/main.php';
