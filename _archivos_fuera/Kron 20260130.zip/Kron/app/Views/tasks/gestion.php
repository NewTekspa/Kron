<?php
/** @var string $title */
/** @var array $teamStats */
/** @var array $collaboratorStats */
/** @var string $monthLabel */
/** @var int $totalTasks */
/** @var int $totalCompleted */
/** @var float $totalHours */
/** @var float $completionRate */
/** @var string $content */
ob_start();
?>
<div class="page-header">
    <h1>Gestion</h1>
    <div class="muted">Productividad del mes <?= htmlspecialchars($monthLabel) ?></div>
</div>

<div class="summary-grid">
    <div class="summary-card">
        <h3>Tareas creadas</h3>
        <p><?= htmlspecialchars((string) $totalTasks) ?></p>
    </div>
    <div class="summary-card">
        <h3>Tareas terminadas</h3>
        <p><?= htmlspecialchars((string) $totalCompleted) ?></p>
    </div>
    <div class="summary-card">
        <h3>Horas registradas</h3>
        <p><?= htmlspecialchars(number_format($totalHours, 1)) ?> h</p>
    </div>
    <div class="summary-card">
        <h3>Cumplimiento</h3>
        <p><?= htmlspecialchars(number_format($completionRate, 1)) ?>%</p>
    </div>
</div>

<section class="card-block">
    <div class="card-header">
        <div>
            <h2>Productividad</h2>
            <p class="muted">Resumen por equipos y colaboradores.</p>
        </div>
        <div class="filter-bar">
            <label for="productivityView">Vista</label>
            <select id="productivityView">
                <option value="teams">Equipos</option>
                <option value="users">Colaboradores</option>
            </select>
        </div>
    </div>

    <div class="view-panel" data-view="teams">
        <div class="table-wrap">
            <table class="table table-compact">
                <thead>
                    <tr>
                        <th>Equipo</th>
                        <th class="table-center">Colaboradores</th>
                        <th class="table-center">Tareas</th>
                        <th class="table-center">Terminadas</th>
                        <th class="table-center">Cumplimiento</th>
                        <th class="table-center">Horas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($teamStats)): ?>
                        <tr>
                            <td colspan="6" class="muted">No hay equipos disponibles.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($teamStats as $team): ?>
                            <tr>
                                <td><?= htmlspecialchars($team['nombre']) ?></td>
                                <td class="table-center"><?= htmlspecialchars((string) $team['colaboradores']) ?></td>
                                <td class="table-center"><?= htmlspecialchars((string) $team['total']) ?></td>
                                <td class="table-center"><?= htmlspecialchars((string) $team['terminadas']) ?></td>
                                <td class="table-center"><?= htmlspecialchars(number_format((float) $team['cumplimiento'], 1)) ?>%</td>
                                <td class="table-center"><?= htmlspecialchars(number_format((float) $team['horas'], 1)) ?> h</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="view-panel is-hidden" data-view="users">
        <div class="table-wrap">
            <table class="table table-compact">
                <thead>
                    <tr>
                        <th>Colaborador</th>
                        <th>Rol</th>
                        <th class="table-center">Tareas</th>
                        <th class="table-center">Terminadas</th>
                        <th class="table-center">Cumplimiento</th>
                        <th class="table-center">Horas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($collaboratorStats)): ?>
                        <tr>
                            <td colspan="6" class="muted">No hay colaboradores disponibles.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($collaboratorStats as $collaborator): ?>
                            <tr>
                                <td><?= htmlspecialchars($collaborator['nombre']) ?></td>
                                <td><?= htmlspecialchars($collaborator['rol']) ?></td>
                                <td class="table-center"><?= htmlspecialchars((string) $collaborator['total']) ?></td>
                                <td class="table-center"><?= htmlspecialchars((string) $collaborator['terminadas']) ?></td>
                                <td class="table-center"><?= htmlspecialchars(number_format((float) $collaborator['cumplimiento'], 1)) ?>%</td>
                                <td class="table-center"><?= htmlspecialchars(number_format((float) $collaborator['horas'], 1)) ?> h</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<script>
(() => {
    const selector = document.getElementById('productivityView');
    if (!selector) {
        return;
    }
    const panels = document.querySelectorAll('.view-panel');
    const toggle = () => {
        const value = selector.value;
        panels.forEach((panel) => {
            panel.classList.toggle('is-hidden', panel.dataset.view !== value);
        });
    };
    selector.addEventListener('change', toggle);
    toggle();
})();
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
