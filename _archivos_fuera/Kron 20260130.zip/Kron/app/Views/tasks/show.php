<?php
/** @var string $title */
/** @var array $task */
/** @var array $logs */
/** @var array $times */
/** @var string|null $error */
/** @var int $authUserId */
/** @var string $roleName */
/** @var bool $isAdmin */
/** @var string|null $returnUrl */
ob_start();
$statusLabels = [
    'pendiente' => 'Pendiente',
    'en_curso' => 'En curso',
    'atrasada' => 'Atrasada',
    'congelada' => 'Congelada',
    'terminada' => 'Terminada',
];
$priorityLabels = [
    'baja' => 'Baja',
    'media' => 'Media',
    'alta' => 'Alta',
    'critica' => 'Critica',
];
$formatDate = function (?string $value): string {
    if (! $value) {
        return '-';
    }
    $timestamp = strtotime($value);
    return $timestamp ? date('d-m-Y', $timestamp) : $value;
};
$formatDateTime = function (?string $value): string {
    if (! $value) {
        return '-';
    }
    $timestamp = strtotime($value);
    return $timestamp ? date('d-m-Y H:i', $timestamp) : $value;
};
?>
<div class="page-header">
    <h1>Detalle de tarea</h1>
    <div class="hero-actions">
        <a href="<?= htmlspecialchars($returnUrl ?? '/tareas') ?>" class="btn btn-secondary">Volver</a>
        <a href="/tareas/editar?id=<?= (int) $task['id'] ?><?= $returnUrl ? '&return=' . urlencode($returnUrl) : '' ?>" class="btn btn-secondary">Editar</a>
        <?php if ($isAdmin || (int) ($task['user_id'] ?? 0) === (int) $authUserId): ?>
            <form method="post" action="/tareas/eliminar" class="inline" onsubmit="return confirm('Eliminar tarea?');">
                <input type="hidden" name="task_id" value="<?= (int) $task['id'] ?>">
                <?php if ($returnUrl): ?>
                    <input type="hidden" name="return_url" value="<?= htmlspecialchars($returnUrl) ?>">
                <?php endif; ?>
                <button type="submit" class="btn btn-danger">Eliminar</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php if (! empty($error)): ?>
    <div class="alert"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="summary-grid">
    <div class="summary-card">
        <h3>Titulo</h3>
        <p><?= htmlspecialchars($task['titulo']) ?></p>
    </div>
    <div class="summary-card">
        <h3>Asignado</h3>
        <p><?= htmlspecialchars($task['asignado_nombre'] ?? '-') ?> (<?= htmlspecialchars($task['asignado_email'] ?? '-') ?>)</p>
    </div>
    <div class="summary-card">
        <h3>Actividad</h3>
        <p><?= htmlspecialchars($task['categoria_nombre'] ?? '-') ?></p>
    </div>
    <div class="summary-card">
        <h3>Prioridad</h3>
        <p><?= htmlspecialchars($priorityLabels[$task['prioridad']] ?? $task['prioridad']) ?></p>
    </div>
    <div class="summary-card">
        <h3>Estado</h3>
        <p><?= htmlspecialchars($statusLabels[$task['estado']] ?? $task['estado']) ?></p>
    </div>
    <div class="summary-card">
        <h3>Compromiso</h3>
        <p><?= htmlspecialchars($formatDate($task['fecha_compromiso'])) ?></p>
    </div>
    <div class="summary-card">
        <h3>Termino real</h3>
        <p><?= htmlspecialchars($formatDate($task['fecha_termino_real'] ?? null)) ?></p>
    </div>
    <div class="summary-card">
        <h3>Creada por</h3>
        <p><?= htmlspecialchars($task['creador_nombre']) ?></p>
    </div>
</div>

<div class="form-grid">
    <form method="post" action="/tareas/bitacora" class="form">
        <h2>Agregar observacion</h2>
        <input type="hidden" name="task_id" value="<?= (int) $task['id'] ?>">
        <label>Observacion</label>
        <textarea name="contenido" rows="4" required></textarea>
        <div class="form-actions">
            <button type="submit" class="btn">Agregar</button>
        </div>
    </form>

    <?php if ($isAdmin || (int) $task['user_id'] === (int) $authUserId): ?>
        <form method="post" action="/tareas/tiempo" class="form">
            <h2>Registrar horas</h2>
            <input type="hidden" name="task_id" value="<?= (int) $task['id'] ?>">
            <label>Fecha</label>
            <input type="date" name="fecha" required>
            <label>Horas (HH:MM)</label>
            <input type="time" name="horas" step="60" required>
            <div class="form-actions">
                <button type="submit" class="btn">Registrar</button>
            </div>
        </form>
    <?php endif; ?>
</div>

<div class="summary-grid">
    <div class="summary-card">
        <h3>Bitacora (<?= count($logs) ?>)</h3>
        <?php if (empty($logs)): ?>
            <p class="muted">Sin observaciones.</p>
        <?php else: ?>
            <div class="log-list">
                <?php foreach ($logs as $log): ?>
                    <div class="log-item">
                        <div class="log-meta"><?= htmlspecialchars($log['autor_nombre']) ?> - <?= htmlspecialchars($formatDateTime($log['created_at'] ?? null)) ?></div>
                        <div><?= nl2br(htmlspecialchars($log['contenido'])) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="summary-card">
        <h3>Horas registradas (<?= count($times) ?>)</h3>
        <?php if (empty($times)): ?>
            <p class="muted">Sin horas.</p>
        <?php else: ?>
            <div class="time-list">
                <?php foreach ($times as $time): ?>
                    <?php
                    $decimal = (float) $time['horas'];
                    $hours = (int) floor($decimal);
                    $minutes = (int) round(($decimal - $hours) * 60);
                    if ($minutes === 60) {
                        $hours += 1;
                        $minutes = 0;
                    }
                    $timeLabel = sprintf('%02d:%02d', $hours, $minutes);
                    ?>
                    <div class="time-item">
                        <div class="time-meta">
                            <span><?= htmlspecialchars($formatDate($time['fecha'] ?? null)) ?></span>
                            <strong><?= htmlspecialchars($timeLabel) ?></strong>
                        </div>
                        <?php if ($isAdmin || (int) $task['user_id'] === (int) $authUserId): ?>
                            <div class="time-actions">
                                <form method="post" action="/tareas/tiempo/eliminar" class="inline" onsubmit="return confirm('Eliminar registro de horas?');">
                                    <input type="hidden" name="task_id" value="<?= (int) $task['id'] ?>">
                                    <input type="hidden" name="time_id" value="<?= (int) $time['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-small">Eliminar</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
