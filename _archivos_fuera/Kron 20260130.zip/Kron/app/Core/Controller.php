<?php

namespace App\Core;

class Controller
{
    protected function view(string $view, array $data = []): void
    {
        $data['authUser'] = Auth::user();
        $data['isAdmin'] = Auth::isAdmin();
        $data['roleName'] = Auth::roleName();
        extract($data, EXTR_SKIP);

        $path = __DIR__ . '/../Views/' . $view . '.php';
        if (! file_exists($path)) {
            http_response_code(500);
            echo 'Vista no encontrada.';
            return;
        }

        require $path;
    }

    protected function requireLogin(): void
    {
        if (! Auth::check()) {
            header('Location: /acceso');
            exit;
        }
    }

    protected function requireAdmin(): void
    {
        if (! Auth::isAdmin()) {
            http_response_code(403);
            echo 'Acceso denegado.';
            exit;
        }
    }
}
