# Guía de Despliegue - KRON

## 📋 Archivos Necesarios para Producción

La aplicación está lista para desplegar. Solo necesitas los siguientes archivos/carpetas:

```
Kron/
├── .htaccess          # Configuración Apache (reescritura URLs)
├── app/               # Lógica de la aplicación
│   ├── Controllers/   # Controladores
│   ├── Core/          # Núcleo (Auth, Database, Router)
│   ├── Models/        # Modelos de datos
│   └── Views/         # Vistas PHP
├── bootstrap/         # Inicialización de la app
├── config/            # Configuración (database, routes, app)
├── logs/              # Logs de la aplicación (debe ser escribible)
└── public/            # Punto de entrada web
    ├── index.php      # Archivo principal
    └── assets/        # CSS, JS, imágenes
```

**Archivos movidos a TEMP/** (no necesarios en producción):
- `php_server.err`, `php_server.out` - Logs del servidor de desarrollo
- `docs/` - Documentación (SQL schemas, reglas de acceso)
- `.deployignore` - Lista de exclusión para despliegue
- `DEPLOYMENT.md` - Guía técnica de despliegue
- `.idea/` - Configuración de IDE

---

## 🚀 Pasos para Desplegar en Host Remoto

### 1️⃣ Subir Archivos al Servidor

**Opción A: FTP/SFTP**
```
- Conecta por FTP a: ftp.newtek.cl
- Sube todos los archivos/carpetas (excepto TEMP/) a:
  /public_html/kron/
```

**Opción B: SSH/Terminal**
```bash
# Comprimir localmente (desde PowerShell en Windows)
Compress-Archive -Path app,bootstrap,config,public,.htaccess,logs -DestinationPath kron.zip

# Subir por SCP
scp kron.zip usuario@newtek.cl:/home/usuario/public_html/kron/

# En el servidor
cd /home/usuario/public_html/kron/
unzip kron.zip
```

---

### 2️⃣ Configurar Base de Datos

**Opción A: Instalador Web (Recomendado) ✨**

1. Crear base de datos vacía en cPanel: `newtek_kron`
2. Crear usuario: `newtek_kron_user` con permisos completos
3. Configurar `config/database.php` con las credenciales
4. Acceder a: `https://www.newtek.cl/kron/install.php`
5. Hacer clic en "Instalar Base de Datos"
6. **¡ELIMINAR install.php después de usarlo!**

**Opción B: Manual (cPanel/PHPMyAdmin)**

1. Crear base de datos: `newtek_kron`
2. Crear usuario: `newtek_kron_user`
3. Asignar permisos completos al usuario
4. Importar el schema desde `TEMP/docs/001_schema.sql`
5. Importar datos iniciales desde `TEMP/docs/002_seed.sql`

**Configurar conexión en el servidor:**

Editar archivo: `/public_html/kron/config/database.php`

```php
<?php
return [
    'driver' => 'mysql',
    'host' => 'localhost',              // Generalmente 'localhost' en hosting compartido
    'port' => 3306,
    'database' => 'newtek_kron',        // Nombre de tu BD
    'username' => 'newtek_kron_user',   // Usuario de BD
    'password' => 'TU_CONTRASEÑA_SEGURA', // Contraseña del usuario
    'charset' => 'utf8mb4'
];
```

⚠️ **NOTA:** El instalador `install.php` es compatible con ambos formatos de configuración:
- Estilo Laravel: `database`, `username`, `password`
- Estilo simple: `name`, `user`, `pass`

---

### 3️⃣ Configurar Permisos

**Desde SSH o panel de archivos:**

```bash
# La carpeta logs debe ser escribible por Apache
chmod 755 /home/usuario/public_html/kron/logs

# Si el servidor web corre como www-data
chown -R www-data:www-data /home/usuario/public_html/kron/logs
```

---

### 4️⃣ Configurar Apache/Nginx

#### **Apache (.htaccess ya incluido)**

El archivo `.htaccess` ya está configurado para subdirectorio `/kron/`:

```apache
RewriteEngine On
RewriteBase /kron/

# Redirigir todo a index.php excepto archivos existentes
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [L,QSA]
```

✅ **No requiere configuración adicional si Apache tiene mod_rewrite activo**

#### **Nginx (si aplica)**

Agregar en el bloque `server` de tu sitio:

```nginx
location /kron {
    alias /home/usuario/public_html/kron/public;
    index index.php;
    
    try_files $uri $uri/ /kron/index.php?$query_string;
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.4-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $request_filename;
        include fastcgi_params;
    }
}
```

---

### 5️⃣ Verificar Configuración de PHP

**Requisitos mínimos:**
- PHP 8.0+ (recomendado 8.4.15)
- Extensiones: `pdo_mysql`, `mbstring`, `json`

**Verificar en servidor:**
```bash
php -v                    # Ver versión PHP
php -m | grep pdo_mysql   # Verificar extensión MySQL
```

---

### 6️⃣ Acceder a la Aplicación

**URL de acceso:**
```
https://www.newtek.cl/kron
```

**Credenciales por defecto:**
- **Administrador:**
  - Email: `administrador@gmail.com`
  - Password: `admin123`

⚠️ **IMPORTANTE:** Cambia esta contraseña inmediatamente en producción.

---

## 🔒 Seguridad Post-Despliegue

### 1. Cambiar contraseñas
```sql
-- Conectar a la base de datos
UPDATE KRON_USERS SET password = PASSWORD('nueva_clave_segura') WHERE email = 'admin@kron.local';
```

### 2. Configurar HTTPS
- Activar SSL en cPanel o panel del hosting
- Forzar HTTPS en `.htaccess`:
```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 3. Proteger config/
Asegurar que archivos `.php` en `config/` no sean accesibles directamente:
```apache
<FilesMatch "^(database|app)\.php$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

### 4. Ocultar logs/
```apache
<Directory logs>
    Order deny,allow
    Deny from all
</Directory>
```

---

## 🛠️ Comandos Útiles en el Servidor

### Ver logs de error PHP
```bash
tail -f /home/usuario/public_html/kron/logs/*.log
```

### Verificar permisos
```bash
ls -la /home/usuario/public_html/kron/
```

### Probar conexión a BD
```bash
mysql -u newtek_kron_user -p newtek_kron
```

---

## 📞 Checklist Final

- ✅ Archivos subidos a `/public_html/kron/` (excepto carpeta TEMP/)
- ✅ Base de datos creada (vacía)
- ✅ `config/database.php` configurado con credenciales correctas
- ✅ Ejecutado `install.php` y creadas las tablas
- ✅ Archivo `install.php` eliminado del servidor
- ✅ Permisos 755 en carpeta `logs/`
- ✅ `.htaccess` con `RewriteBase /kron/`
- ✅ URL accesible: `https://www.newtek.cl/kron`
- ✅ Login funcional: `administrador@gmail.com` / `admin123`
- ✅ Contraseña de admin cambiada en producción

---

## 🐛 Troubleshooting

**Error 500 - Internal Server Error**
- Verificar `logs/error.log` en el servidor
- Comprobar que `mod_rewrite` esté activo: `apache2ctl -M | grep rewrite`
- Revisar permisos de carpetas (755) y archivos (644)

**Página en blanco**
- Activar errores de PHP temporalmente en `config/app.php`:
  ```php
  ini_set('display_errors', 1);
  error_reporting(E_ALL);
  ```

**CSS/JS no carga**
- Verificar rutas en `app/Views/layouts/main.php`:
  ```php
  <link rel="stylesheet" href="/kron/assets/css/app.css">
  ```

**Error de conexión BD**
- Verificar credenciales en `config/database.php`
- Confirmar que el usuario tiene permisos en la BD
- Comprobar que el host sea `localhost` (en hosting compartido)

---

## 📧 Soporte

Para dudas o problemas, revisar:
- `TEMP/docs/STATUS.md` - Estado del proyecto
- `TEMP/docs/reglas-acceso.md` - Permisos por rol
- Logs en carpeta `logs/`
