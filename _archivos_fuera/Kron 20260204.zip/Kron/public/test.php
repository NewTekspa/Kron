<?php
// Test básico de PHP para verificar ejecución en el servidor

echo "<h1>Test PHP OK</h1>";
echo "<p>La ejecución de PHP funciona correctamente en este servidor.</p>";

// Información básica de PHP
phpinfo();
