# Guía de Despliegue - KRON Task Management

## Archivos Necesarios para el Servidor

### 1. Estructura de Directorios Requerida

```
servidor/
├── app/
│   ├── Controllers/
│   │   ├── AuthController.php
│   │   ├── HomeController.php
│   │   ├── TaskController.php
│   │   ├── TaskGestionController.php
│   │   ├── TaskManagementController.php
│   │   └── Admin/
│   │       ├── ClassificationController.php
│   │       ├── RoleController.php
│   │       ├── TeamController.php
│   │       └── UserController.php
│   ├── Core/
│   │   ├── Auth.php
│   │   ├── Controller.php
│   │   ├── Database.php
│   │   └── Router.php
│   ├── Models/
│   │   ├── Role.php
│   │   ├── Task.php
│   │   ├── TaskCategory.php
│   │   ├── TaskClassification.php
│   │   ├── TaskIndicator.php
│   │   ├── Team.php
│   │   ├── TeamTaskIndicator.php
│   │   ├── User.php
│   │   └── UserRelation.php
│   └── Views/
│       ├── home.php
│       ├── admin/
│       │   ├── classifications/
│       │   │   └── index.php
│       │   ├── roles/
│       │   │   └── index.php
│       │   ├── teams/
│       │   │   ├── index.php
│       │   │   └── show.php
│       │   └── users/
│       │       ├── create.php
│       │       ├── edit.php
│       │       └── index.php
│       ├── auth/
│       │   └── login.php
│       ├── layouts/
│       │   └── main.php
│       └── tasks/
│           ├── edit.php
│           ├── gestion.php
│           ├── index.php
│           ├── manage.php
│           ├── revision.php
│           └── show.php
├── bootstrap/
│   └── app.php
├── config/
│   ├── app.php
│   ├── database.php
│   └── routes.php
├── public/
│   ├── index.php
│   ├── .htaccess
│   └── assets/
│       ├── css/
│       │   └── app.css
│       └── js/
│           └── chart.min.js
├── logs/
│   └── .gitkeep
└── docs/
    ├── 001_schema.sql
    └── 002_seed.sql
```

### 2. Archivos que NO deben subirse al servidor

**Excluir:**
- `php_server.err`
- `.git/` (directorio completo)
- `.vscode/` (directorio completo)
- `*.log`
- `composer.lock` (solo si no usas composer)
- `.env.local` o archivos de configuración local
- `/logs/*.log` (mantener solo el directorio vacío)

### 3. Despliegue en Subdirectorio (Ejemplo: https://www.newtek.cl/kron)

Si vas a desplegar en un subdirectorio en lugar de la raíz del dominio, sigue estos pasos adicionales:

#### 3.1 Ubicación de Archivos

En el servidor, coloca los archivos en:
```
/home/usuario/public_html/kron/
```

La estructura debe quedar:
```
/home/usuario/public_html/kron/
├── app/
├── bootstrap/
├── config/
├── public/
│   └── index.php
└── ...
```

#### 3.2 Configuración del Virtual Host o .htaccess Principal

Si tienes acceso al Virtual Host de Apache, configura el DocumentRoot apuntando a `/kron/public`:

```apache
<VirtualHost *:443>
    ServerName www.newtek.cl
    DocumentRoot /home/usuario/public_html
    
    Alias /kron /home/usuario/public_html/kron/public
    <Directory /home/usuario/public_html/kron/public>
        AllowOverride All
        Require all granted
        
        <IfModule mod_rewrite.c>
            RewriteEngine On
            RewriteBase /kron/
            RewriteCond %{REQUEST_FILENAME} !-f
            RewriteCond %{REQUEST_FILENAME} !-d
            RewriteRule ^(.*)$ index.php [QSA,L]
        </IfModule>
    </Directory>
</VirtualHost>
```

#### 3.3 Actualizar .htaccess en /kron/public/

Modifica el archivo `public/.htaccess`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /kron/
    
    # Redirigir todo al index.php
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ index.php [QSA,L]
</IfModule>
```

#### 3.4 Actualizar Rutas de Assets

En `app/Views/layouts/main.php`, actualizar las rutas de CSS/JS:

```php
<link rel="stylesheet" href="/kron/assets/css/app.css">
```

Y en las vistas donde se use Chart.js desde local (si aplica):

```html
<script src="/kron/assets/js/chart.min.js"></script>
```

#### 3.5 Actualizar config/app.php

Si el archivo existe, agregar la base path:

```php
<?php
return [
    'base_path' => '/kron',
    'url' => 'https://www.newtek.cl/kron',
    // ... otras configuraciones
];
```

#### 3.6 URL de Acceso

Una vez configurado, accede a la aplicación en:
```
https://www.newtek.cl/kron/
```

La página de login será:
```
https://www.newtek.cl/kron/acceso
```

**Importante:** Todas las rutas internas de la aplicación (enlaces `href="/..."`) deben incluir el prefijo `/kron`:
- `/kron/` → Inicio
- `/kron/acceso` → Login
- `/kron/tareas` → Tareas
- `/kron/admin/usuarios` → Usuarios
- etc.

### 4. Configuración del Servidor (Raíz del Dominio)

#### 4.1 Requisitos del Servidor
- **PHP:** 8.0 o superior
- **MySQL:** 5.7 o superior / MariaDB 10.3+
- **Apache** con mod_rewrite habilitado O **Nginx**
- **Extensiones PHP requeridas:**
  - PDO
  - pdo_mysql
  - mbstring
  - session

#### 4.2 Configuración de Apache (.htaccess)

El archivo `public/.htaccess` debe contener:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    
    # Redirigir todo al index.php
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ index.php [QSA,L]
</IfModule>
```

**Archivo raíz .htaccess** (en la raíz del proyecto, no en public/):

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^(.*)$ public/$1 [L]
</IfModule>
```

#### 4.3 Configuración de Nginx

```nginx
server {
    listen 80;
    server_name tu-dominio.com;
    root /ruta/completa/al/proyecto/public;

    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

### 5. Configuración de Base de Datos

#### 5.1 Crear la Base de Datos

```bash
mysql -u root -p
CREATE DATABASE kron_tasks CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'kron_user'@'localhost' IDENTIFIED BY 'password_seguro';
GRANT ALL PRIVILEGES ON kron_tasks.* TO 'kron_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

#### 5.2 Importar el Schema

```bash
mysql -u kron_user -p kron_tasks < docs/001_schema.sql
mysql -u kron_user -p kron_tasks < docs/002_seed.sql
```

#### 5.3 Actualizar config/database.php

```php
<?php
return [
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'kron_tasks',
    'username' => 'kron_user',
    'password' => 'password_seguro',
    'charset' => 'utf8mb4',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ],
];
```

### 6. Permisos de Archivos

```bash
# Permisos de directorios
find . -type d -exec chmod 755 {} \;

# Permisos de archivos
find . -type f -exec chmod 644 {} \;

# Permisos especiales para logs (escritura)
chmod 775 logs/
```

### 7. Checklist de Despliegue

- [ ] Subir todos los archivos excepto los excluidos
- [ ] Configurar la base de datos (crear, importar schema y seed)
- [ ] Actualizar `config/database.php` con credenciales del servidor
- [ ] Verificar que `public/` sea el DocumentRoot del servidor
- [ ] Configurar `.htaccess` o Nginx según corresponda
- [ ] Establecer permisos correctos (755 directorios, 644 archivos, 775 logs)
- [ ] Verificar que mod_rewrite esté habilitado (Apache)
- [ ] Probar acceso: http://tu-dominio.com/acceso
- [ ] Credenciales por defecto: admin@kron.com / admin123
- [ ] Verificar que los logs se escriban correctamente en /logs/

### 8. Solución de Problemas Comunes

#### Error 500 - Internal Server Error
- Verificar permisos de archivos
- Revisar logs de Apache/Nginx: `/var/log/apache2/error.log` o `/var/log/nginx/error.log`
- Verificar que todas las extensiones PHP requeridas estén instaladas

#### Página en blanco
- Habilitar display_errors en desarrollo: `ini_set('display_errors', 1);` en `public/index.php`
- Revisar logs de PHP

#### Error de conexión a base de datos
- Verificar credenciales en `config/database.php`
- Confirmar que el usuario MySQL tenga permisos
- Verificar que el servicio MySQL esté corriendo

#### Rutas no funcionan (404 en todas las páginas)
- Verificar que mod_rewrite esté habilitado: `sudo a2enmod rewrite && sudo service apache2 restart`
- Verificar que `.htaccess` tenga el contenido correcto
- Verificar que AllowOverride esté en `All` en la configuración de Apache

### 9. Seguridad Adicional (Recomendado)

#### 9.1 Protección adicional de directorios

Crear `.htaccess` en `/app`, `/bootstrap`, `/config`, `/logs`:

```apache
Deny from all
```

#### 9.2 Desactivar listado de directorios

En `public/.htaccess` agregar:

```apache
Options -Indexes
```

#### 9.3 Cambiar contraseñas por defecto

Una vez desplegado, cambiar inmediatamente la contraseña del usuario administrador desde la interfaz.

---

## Comandos Rápidos de Despliegue

### Comprimir archivos para transferencia (desde Windows PowerShell)

```powershell
# Crear archivo ZIP excluyendo archivos innecesarios
Compress-Archive -Path app,bootstrap,config,docs,public -DestinationPath kron-deploy.zip
```

### Descomprimir en servidor (Linux)

```bash
unzip kron-deploy.zip -d /var/www/tu-sitio/
cd /var/www/tu-sitio/
chmod -R 755 .
chmod 775 logs/
```

---

**Nota:** Asegúrate de mantener copias de seguridad regulares de la base de datos y del directorio de logs.
