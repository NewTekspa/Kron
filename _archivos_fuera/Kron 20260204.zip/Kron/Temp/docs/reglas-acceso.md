Reglas de acceso y jerarquia

1) Estructura de roles
- Colaborador
- Jefe
- Subgerente

2) Jerarquia
- Cada colaborador pertenece a un jefe.
- Cada jefe pertenece a un subgerente.

3) Permisos por rol
- Colaborador: puede ver y editar solo sus propios datos.
- Jefe: puede ver y editar los datos de todos los colaboradores bajo su cargo.
- Subgerente: puede ver y editar los datos de jefes y colaboradores bajo su cargo.

4) Modelo de equipo
- El acceso se determina por la formacion de equipos (relacion jefe-subgerente-colaborador).

5) Convencion de base de datos
- Todas las tablas deben usar el prefijo "KRON_".
