<?php
ob_start();
?>
<div class="page-header">
    <div>
        <h1 style="display: flex; align-items: center; gap: 12px;">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--blue);">
                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
            </svg>
            Gestor de tareas
        </h1>
        <p class="muted" style="margin: 4px 0 0 44px; font-size: 15px;">Bienvenido, <strong style="color: var(--text-medium);"><?= htmlspecialchars($authUser['nombre'] ?? 'Usuario') ?></strong></p>
    </div>
</div>
<div class="hero-actions" style="margin-bottom: 18px;">
    <button type="button" class="btn" data-open-modal="activityModal">Nueva actividad</button>
</div>

<div class="modal" id="activityModal" data-modal>
    <div class="modal-overlay" data-close-modal></div>
    <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="activityModalTitle">
        <div class="modal-header">
            <h2 id="activityModalTitle">Nueva actividad</h2>
            <button type="button" class="btn btn-secondary btn-small" data-close-modal>Cerrar</button>
        </div>
        <form method="post" action="<?= $basePath ?>/tareas/gestor/crear-actividad" class="form">
            <label>Nombre de la actividad</label>
            <input type="text" name="nombre" required>
            <label>Clasificación</label>
            <select name="clasificacion_id" required>
                <option value="">Selecciona una clasificación</option>
                <?php if (!empty($clasificaciones)): ?>
                    <?php foreach ($clasificaciones as $cl): ?>
                        <option value="<?= (int)$cl['id'] ?>"><?= htmlspecialchars($cl['nombre']) ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
            <label>Equipo responsable</label>
            <select name="team_id" required>
                <option value="">Selecciona un equipo</option>
                <?php if (!empty($equipos)): ?>
                    <?php foreach ($equipos as $team): ?>
                        <option value="<?= (int)$team['id'] ?>"<?= (isset($equipoPorDefecto) && $equipoPorDefecto == $team['id'] ? ' selected' : '') ?>><?= htmlspecialchars($team['nombre']) ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
            <div class="form-actions">
                <button type="submit" class="btn">Crear actividad</button>
            </div>
        </form>
    </div>
</div>

<div class="dashboard-top">
    <div class="dashboard-col" style="flex: 2 1 0; min-width: 900px; max-width: 1200px; margin: 0 auto;">
        <section class="card-block dashboard-card" style="background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); box-shadow: var(--shadow); min-height: 420px;">
            <div class="card-header">
                <div style="display: flex; align-items: flex-start; gap: 12px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                    </div>
                    <div>
                        <h2 style="margin: 0 0 4px;">Mis actividades</h2>
                        <p class="muted" style="margin: 0; font-size: 13px;">📋 Actividades donde participas</p>
                    </div>
                </div>
            </div>
            <div class="table-wrap" style="margin-top: 24px;">
                <table class="table table-compact">
                    <thead>
                        <tr>
                            <th>Actividad</th>
                            <th>Clasificación</th>
                            <th class="table-center">Total tareas</th>
                            <th class="table-center">Estado</th>
                            <th class="table-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($activities)): ?>
                            <?php foreach ($activities as $actividad): ?>
                                <tr>
                                    <td><?= htmlspecialchars($actividad['nombre']) ?></td>
                                    <td><?= htmlspecialchars($actividad['clasificacion_nombre'] ?? '-') ?></td>
                                    <td class="table-center"><?= (int)$actividad['total_tareas'] ?></td>
                                    <td class="table-center">
                                        <?= htmlspecialchars($actividad['estado_actividad'] ?? '-') ?>
                                    </td>
                                    <td class="table-center">
                                        <a href="<?= $basePath ?>/tareas/actividad?category_id=<?= (int)$actividad['id'] ?>" class="btn btn-secondary btn-small">Ver tareas</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="muted">No tienes actividades asignadas.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
