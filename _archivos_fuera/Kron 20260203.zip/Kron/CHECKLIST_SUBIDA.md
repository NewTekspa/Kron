## 📋 Checklist de Archivos para Subir

**Fecha:** 1 febrero 2026
**Servidor:** https://www.newtek.cl/kron/

---

### ⚠️ ARCHIVOS CRÍTICOS - SUBIR AHORA

Estos archivos contienen los cambios para que las redirecciones y URLs funcionen correctamente:

**Core y Controladores (8 archivos):**
- [ ] `app/Core/Controller.php`
- [ ] `app/Controllers/AuthController.php`
- [ ] `app/Controllers/TaskController.php`
- [ ] `app/Controllers/TaskManagementController.php`
- [ ] `app/Controllers/Admin/UserController.php`
- [ ] `app/Controllers/Admin/RoleController.php`
- [ ] `app/Controllers/Admin/ClassificationController.php`
- [ ] `app/Controllers/Admin/TeamController.php`

**Vistas (15 archivos):**
- [ ] `app/Views/auth/login.php`
- [ ] `app/Views/home.php`
- [ ] `app/Views/tasks/index.php`
- [ ] `app/Views/tasks/edit.php`
- [ ] `app/Views/tasks/show.php`
- [ ] `app/Views/tasks/gestion.php`
- [ ] `app/Views/tasks/revision.php`
- [ ] `app/Views/tasks/manage.php`
- [ ] `app/Views/admin/users/index.php`
- [ ] `app/Views/admin/users/create.php`
- [ ] `app/Views/admin/users/edit.php`
- [ ] `app/Views/admin/roles/index.php`
- [ ] `app/Views/admin/teams/index.php`
- [ ] `app/Views/admin/teams/show.php`
- [ ] `app/Views/admin/classifications/index.php`

**TOTAL: 23 archivos**

---

### ✅ Verificar que ya están en servidor

Estos archivos deberían estar ya subidos (de cambios anteriores):

- [x] `.htaccess` (raíz)
- [x] `public/.htaccess`
- [x] `app/Core/Router.php`
- [x] `config/app.php`
- [x] `bootstrap/app.php`
- [x] `app/Views/layouts/main.php`

---

### 🧪 Después de subir

- [ ] Probar login en: https://www.newtek.cl/kron/acceso
  - Usuario: `administrador@gmail.com`
  - Contraseña: `admin123`
  
- [ ] Verificar que redirige a: https://www.newtek.cl/kron/ (sin 404)

- [ ] Probar navegación:
  - [ ] Ver tareas
  - [ ] Crear tarea
  - [ ] Editar tarea
  - [ ] Cerrar sesión
  - [ ] Administración de usuarios

---

### 🗑️ Después de que funcione todo

- [ ] Eliminar `public/install.php` del servidor (seguridad)
- [ ] Cambiar contraseña del administrador
- [ ] Crear usuarios adicionales

---

### 📝 Notas

**Ruta en servidor:** `/home/newtekcl/public_html/kron/`

**Método de subida recomendado:**
1. FTP/SFTP
2. File Manager del hosting
3. SSH con scp/rsync

**Permisos recomendados:**
- Archivos PHP: `644`
- Carpetas: `755`
