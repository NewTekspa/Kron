<?php

return [
    'driver' => 'mysql',
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => 'newtekcl_Db_NewTek',
    'username' => 'newtekcl_newtek',
    'password' => 'Tony@236974.',
    'charset' => 'utf8mb4',
];
