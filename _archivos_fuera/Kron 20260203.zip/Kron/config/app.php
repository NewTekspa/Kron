<?php

return [
    'name' => 'KRON',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'base_path' => '', // Cambiado a '' para desarrollo local
];
