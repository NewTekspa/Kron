<?php

return [
    'name' => 'KRON',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
];
