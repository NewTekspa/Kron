KRON - Estado del proyecto (resumen)

Fecha: 2026-01-29

Resumen general
- Proyecto PHP/MVC simple con auth, panel admin, usuarios, roles y equipos.
- Permisos por rol aplicados a listados/edicion de usuarios (admin ve todo).
- Equipos ahora son entidades con nombre, subgerente, jefe y colaboradores.
- Modulo de tareas con categorias, bitacora y horas por dia.
- Gestion de tareas separada de registro rapido.
- Dashboard en / con tareas abiertas (filtro + acceso directo) y grafico de avance por equipo/colaborador.

Credenciales actuales
- Admin principal: administrador@gmail.com / Admin123!

Base de datos
- Esquema base en docs/001_schema.sql.
- Datos base en docs/002_seed.sql (seed actualizado con admin).
- Tablas nuevas:
  - KRON_TEAMS (nombre, subgerente_id, jefe_id).
  - KRON_TEAM_MEMBERS (team_id, user_id) con user unico por equipo.
  - KRON_TASK_CATEGORIES (nombre, created_by).
  - KRON_TASKS (category_id, user_id, created_by, titulo, fechas, prioridad, estado).
  - fecha_compromiso ahora permite NULL para copiar tareas sin fecha.
  - KRON_TASK_LOGS (bitacora por tarea).
  - KRON_TASK_TIMES (horas por dia, unico por fecha).

Flujo de login
- Acceso en /acceso con Auth::attempt y sesion.
- Redireccion a /admin/usuarios si login correcto.

Roles y permisos
- Roles fijos: administrador, colaborador, jefe, subgerente.
- Admin: CRUD usuarios, roles, equipos.
- No-admin: acceso restringido a usuarios visibles segun equipo (jefe/subgerente).
- Vista de roles: solo editar descripcion (combo) o eliminar; no se crean roles.
- Tareas: colaborador ve solo sus tareas; jefe/subgerente ve su equipo/area; admin ve todo.

Usuarios
- CRUD de usuarios disponible para admin.
- Edicion de usuarios permite cambiar password; rol/estado solo admin.
- Eliminar usuario disponible para admin en /admin/usuarios.

Equipos (nuevo modelo)
- Pantalla /admin/equipos permite:
  - Crear equipo con nombre + subgerente + jefe (autocompletado).
  - Asignar colaborador a un equipo (autocompletado).
  - Ver lista de equipos con colaboradores.
  - Remover colaborador de un equipo.
  - Eliminar equipo.
  - Filtrar equipos por texto (client-side).
- Validaciones:
  - Subgerente debe tener rol subgerente.
  - Jefe debe tener rol jefe.
  - Colaborador debe tener rol colaborador.
  - Cada colaborador solo puede estar en un equipo (se reasigna si cambia).

Autocompletado
- Endpoint: /admin/usuarios/buscar (nombre/email, limita resultados).
- Endpoint: /admin/equipos/buscar (por nombre de equipo).
- Endpoint: /tareas/buscar-usuarios (solo usuarios visibles).
- Endpoint: /tareas/buscar-categorias (por nombre).
- Usado en pantalla de equipos.

Archivos clave modificados/creados
- app/Core/Auth.php (roleName)
- app/Core/Controller.php (roleName en vistas)
- app/Models/User.php (busqueda, delete, visibilidad por equipo)
- app/Models/Role.php (getUserRoleName)
- app/Models/Team.php (nuevo + equipos visibles para dashboard)
- app/Controllers/Admin/UserController.php (filtros por rol, search, delete)
- app/Controllers/Admin/TeamController.php (nuevo flujo equipos)
- app/Views/admin/teams/index.php (nuevo UI equipos)
- app/Views/admin/users/index.php (acciones segun rol)
- app/Views/admin/users/edit.php (rol/estado solo admin)
- app/Views/admin/roles/index.php (solo editar descripcion con combo)
- config/routes.php (nuevas rutas)
- public/assets/css/app.css (estilos autocomplete, equipos)
- docs/001_schema.sql (tablas KRON_TEAMS y KRON_TEAM_MEMBERS + fecha_compromiso nullable)
- docs/002_seed.sql (admin principal)
- app/Models/Task.php (tareas, bitacora, horas, copia, dashboard)
- app/Models/TaskCategory.php (categorias + conteo sin fecha)
- app/Controllers/TaskController.php (tareas, bitacora, horas, copia)
- app/Controllers/HomeController.php (dashboard)
- app/Controllers/TaskManagementController.php (gestion categorias + modal tareas)
- app/Views/tasks/index.php (registro rapido tareas)
- app/Views/tasks/show.php (detalle tarea)
- app/Views/tasks/edit.php (editar tarea)
- app/Views/tasks/manage.php (gestion de tareas, copia por categoria, icono sin fecha, avance)
- app/Views/home.php (dashboard)

Servidor local
- Levantar con:
  C:\php\php.exe -S localhost:8000 -t public
- URL: http://localhost:8000


Cambios recientes (2026-01-29)
- Eliminada la vista de equipos en gestión de tareas: ahora solo se muestra la vista de colaboradores.
- Añadido filtro por equipo en la vista de colaboradores (dropdown), permitiendo ver solo los miembros de un equipo o todos.
- El filtro incluye explícitamente a jefes y subgerentes del equipo seleccionado, además de los colaboradores.
- Unificada la lógica de totales y columnas de estados (Pendientes, Atrasadas, En curso, Terminadas) entre tarjetas resumen y tabla de colaboradores.
- Mejorada la consistencia entre los totales de las tarjetas y la tabla.
- Refactorizado el backend (TaskGestionController.php) para calcular correctamente los usuarios visibles y los estados de tareas según el filtro.
- Actualizada la UI (gestion.php) para reflejar los nuevos filtros, columnas y lógica de resumen.
- Documentación actualizada para reflejar estos cambios.

Pendientes sugeridos
- Migrar datos de KRON_USER_RELATIONS a KRON_TEAMS si aplica.
- Agregar CSRF en formularios y validaciones extra.
