<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;

class AuthController extends Controller
{
    public function showLogin(): void
    {
        $this->view('auth/login', [
            'title' => 'Acceso',
        ]);
    }

    public function login(): void
    {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email === '' || $password === '') {
            $this->view('auth/login', [
                'title' => 'Acceso',
                'error' => 'Debes completar email y contraseña.',
            ]);
            return;
        }

        if (! Auth::attempt($email, $password)) {
            $this->view('auth/login', [
                'title' => 'Acceso',
                'error' => 'Credenciales invalidas o usuario inactivo.',
            ]);
            return;
        }

        header('Location: /');
        exit;
    }

    public function logout(): void
    {
        Auth::logout();
        header('Location: /');
        exit;
    }
}
