<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Models\Task;
use App\Models\TaskCategory;
use App\Models\TaskClassification;

class TaskManagementController extends Controller
{
    public function index(): void
    {
        $this->requireLogin();
        // Permitir acceso a todos los roles autenticados

        $user = Auth::user();
        $visibleIds = [(int) $user['id']];

        $categories = TaskCategory::allWithCounts($visibleIds);
        $classifications = TaskClassification::all();
        $error = trim($_GET['error'] ?? '');

        $this->view('tasks/manage', [
            'title' => 'Gestion de tarea',
            'categories' => $categories,
            'classifications' => $classifications,
            'error' => $error !== '' ? $error : null,
        ]);
    }

    public function storeCategory(): void
    {
        $this->requireLogin();

        $nombre = trim($_POST['nombre'] ?? '');
        $classificationId = (int) ($_POST['classification_id'] ?? 0);
        if ($nombre === '') {
            header('Location: /gestion-tareas?error=Nombre+incompleto');
            exit;
        }

        $user = Auth::user();
        TaskCategory::createWithClassification($nombre, (int) $user['id'], $classificationId > 0 ? $classificationId : null);

        header('Location: /gestion-tareas');
        exit;
    }

    public function updateCategory(): void
    {
        $this->requireLogin();

        $id = (int) ($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $classificationId = (int) ($_POST['classification_id'] ?? 0);
        if ($id === 0 || $nombre === '') {
            header('Location: /gestion-tareas?error=Datos+incompletos');
            exit;
        }

        TaskCategory::updateDetails($id, $nombre, $classificationId > 0 ? $classificationId : null);

        header('Location: /gestion-tareas?categoria_id=' . $id);
        exit;
    }

    public function deleteCategory(): void
    {
        $this->requireLogin();

        $id = (int) ($_POST['id'] ?? 0);
        if ($id === 0) {
            header('Location: /gestion-tareas?error=Categoria+no+valida');
            exit;
        }

        TaskCategory::delete($id);

        header('Location: /gestion-tareas');
        exit;
    }

    public function categoryTasks(): void
    {
        $this->requireLogin();

        $user = Auth::user();
        $categoryId = (int) ($_GET['categoria_id'] ?? 0);

        if ($categoryId <= 0) {
            header('Content-Type: application/json');
            echo json_encode([]);
            return;
        }

        $tasks = Task::allForUserIdsByCategory([(int) $user['id']], $categoryId);

        header('Content-Type: application/json');
        echo json_encode($tasks);
    }

    public function storeClassification(): void
    {
        $this->requireLogin();

        $nombre = trim($_POST['nombre'] ?? '');
        if ($nombre === '') {
            header('Location: /gestion-tareas?error=Nombre+incompleto');
            exit;
        }

        TaskClassification::create($nombre);

        header('Location: /gestion-tareas');
        exit;
    }

    public function updateClassification(): void
    {
        $this->requireLogin();

        $id = (int) ($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        if ($id === 0 || $nombre === '') {
            header('Location: /gestion-tareas?error=Datos+incompletos');
            exit;
        }

        TaskClassification::updateName($id, $nombre);

        header('Location: /gestion-tareas');
        exit;
    }

    public function deleteClassification(): void
    {
        $this->requireLogin();

        $id = (int) ($_POST['id'] ?? 0);
        if ($id === 0) {
            header('Location: /gestion-tareas?error=Clasificacion+no+valida');
            exit;
        }

        TaskClassification::delete($id);

        header('Location: /gestion-tareas');
        exit;
    }
}
