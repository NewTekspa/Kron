<?php
/** @var string $title */
/** @var array|null $authUser */
/** @var bool $isAdmin */
/** @var string|null $roleName */
/** @var string $content */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($title) ?></title>
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
    <header class="topbar">
        <div class="container">
            <div class="brand">KRON</div>
            <nav class="nav">
                <a href="/">Inicio</a>
                <?php if ($authUser): ?>
                    <div class="nav-item has-dropdown">
                        <button type="button" class="nav-link">
                            Tareas
                            <span class="nav-caret">▼</span>
                        </button>
                        <div class="dropdown-menu">
                            <a href="/gestion-tareas">Gestion de tarea</a>
                            <?php if (in_array($roleName ?? '', ['jefe', 'subgerente', 'administrador'], true)): ?>
                                <a href="/tareas/gestion">Seguimiento de Equipo</a>
                            <?php endif; ?>
                            <a href="/tareas">Registro rapido</a>
                        </div>
                    </div>
                    <?php if ($isAdmin): ?>
                        <div class="nav-item has-dropdown">
                            <button type="button" class="nav-link">
                                Configuracion
                                <span class="nav-caret">▼</span>
                            </button>
                            <div class="dropdown-menu">
                                <a href="/admin/usuarios">Usuarios</a>
                                <a href="/admin/roles">Roles</a>
                                <a href="/admin/equipos">Equipos</a>
                                <a href="/admin/categorias">Actividades</a>
                            </div>
                        </div>
                    <?php endif; ?>
                    <a href="/salir">Salir</a>
                <?php else: ?>
                    <a href="/acceso">Acceso</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="container">
        <?= $content ?>
    </main>
</body>
</html>
