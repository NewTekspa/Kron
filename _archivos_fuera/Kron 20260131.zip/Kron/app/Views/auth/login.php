<?php
/** @var string $title */
/** @var string|null $error */
ob_start();
?>
<div class="form-card">
    <h1>Acceso</h1>
    <p>Ingresa con tus credenciales de administrador.</p>
    <?php if (! empty($error)): ?>
        <div class="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post" action="/acceso" class="form">
        <label>Email</label>
        <input type="email" name="email" required>
        <label>Contrasena</label>
        <input type="password" name="password" required>
        <button type="submit" class="btn">Entrar</button>
    </form>
</div>
<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
