<?php
/** @var string $title */
/** @var array $task */
/** @var array $assignableUsers */
/** @var array $statusOptions */
/** @var array $priorityOptions */
/** @var string|null $error */
/** @var int $authUserId */
/** @var string $roleName */
/** @var string|null $returnUrl */
ob_start();
$statusLabels = [
    'pendiente' => 'Pendiente',
    'en_curso' => 'En curso',
    'atrasada' => 'Atrasada',
    'congelada' => 'Congelada',
    'terminada' => 'Terminada',
];
$priorityLabels = [
    'baja' => 'Baja',
    'media' => 'Media',
    'alta' => 'Alta',
    'critica' => 'Critica',
];
?>
<div class="page-header">
    <h1>Editar tarea</h1>
    <div class="hero-actions">
        <a href="<?= htmlspecialchars($returnUrl ?? ('/tareas/detalle?id=' . (int) $task['id'])) ?>" class="btn btn-secondary">Volver</a>
    </div>
</div>
<?php if (! empty($error)): ?>
    <div class="alert"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post" action="/tareas/actualizar" class="form form-card">
    <input type="hidden" name="id" value="<?= (int) $task['id'] ?>">
    <?php if ($returnUrl): ?>
        <input type="hidden" name="return_url" value="<?= htmlspecialchars($returnUrl) ?>">
    <?php endif; ?>
    <label>Titulo</label>
    <input type="text" name="titulo" value="<?= htmlspecialchars($task['titulo']) ?>" required>

    <div class="autocomplete">
        <label>Actividad</label>
        <input type="text" name="category_name" data-source="task-categories" autocomplete="off" value="<?= htmlspecialchars($task['categoria_nombre'] ?? '') ?>" required>
        <input type="hidden" name="category_id" value="<?= (int) ($task['category_id'] ?? 0) ?>">
        <div class="autocomplete-results"></div>
    </div>

    <div class="autocomplete">
        <label>Asignar a</label>
        <input type="text" name="user_label" data-source="task-users" autocomplete="off" value="<?= htmlspecialchars($task['asignado_nombre']) ?> (<?= htmlspecialchars($task['asignado_email']) ?>)" required>
        <input type="hidden" name="user_id" value="<?= (int) $task['user_id'] ?>">
        <div class="autocomplete-results"></div>
    </div>

    <label>Fecha compromiso estimada</label>
    <input type="date" name="fecha_compromiso" value="<?= htmlspecialchars($task['fecha_compromiso']) ?>" required>

    <label>Prioridad</label>
    <select name="prioridad" required>
        <?php foreach ($priorityOptions as $option): ?>
            <option value="<?= htmlspecialchars($option) ?>" <?= $task['prioridad'] === $option ? 'selected' : '' ?>>
                <?= htmlspecialchars($priorityLabels[$option] ?? $option) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Estado</label>
    <select name="estado" required>
        <?php foreach ($statusOptions as $option): ?>
            <option value="<?= htmlspecialchars($option) ?>" <?= $task['estado'] === $option ? 'selected' : '' ?>>
                <?= htmlspecialchars($statusLabels[$option] ?? $option) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <div class="form-actions">
        <button type="submit" class="btn">Guardar cambios</button>
    </div>
</form>
<script>
(() => {
    const debounce = (fn, wait = 300) => {
        let t;
        return (...args) => {
            clearTimeout(t);
            t = setTimeout(() => fn(...args), wait);
        };
    };

    const initAutocomplete = (wrapper) => {
        const input = wrapper.querySelector('input[type="text"]');
        const hidden = wrapper.querySelector('input[type="hidden"]');
        const results = wrapper.querySelector('.autocomplete-results');
        if (!input || !hidden || !results) {
            return;
        }

    const fetchItems = async (term, source, limit = 15) => {
        const params = new URLSearchParams({ q: term, limit });
        const endpoint = source === 'task-categories' ? '/tareas/buscar-categorias' : '/tareas/buscar-usuarios';
        const res = await fetch(`${endpoint}?${params.toString()}`);
        if (!res.ok) {
            return [];
        }
        return res.json();
    };

        const renderResults = (items) => {
            results.innerHTML = '';
            if (!items.length) {
                return;
            }
            items.forEach((item) => {
                const row = document.createElement('div');
                row.className = 'autocomplete-item';
            row.textContent = item.email ? `${item.nombre} (${item.email})` : item.nombre;
            row.addEventListener('click', () => {
                input.value = row.textContent;
                hidden.value = item.id;
                    results.innerHTML = '';
                });
                results.appendChild(row);
            });
        };

        const handle = debounce(async () => {
            const term = input.value.trim();
            hidden.value = '';
        if (term.length < 2) {
            results.innerHTML = '';
            return;
        }
        const items = await fetchItems(term, input.dataset.source);
        renderResults(items);
    });

        input.addEventListener('input', handle);
        document.addEventListener('click', (event) => {
            if (!wrapper.contains(event.target)) {
                results.innerHTML = '';
            }
        });
    };

    const guardForm = (form, fields) => {
        if (!form) {
            return;
        }
        form.addEventListener('submit', (event) => {
            for (const name of fields) {
                if (!form.querySelector(`input[name="${name}"]`)?.value) {
                    event.preventDefault();
                    alert('Selecciona un valor desde la lista.');
                    return;
                }
            }
        });
    };

    document.querySelectorAll('.autocomplete').forEach(initAutocomplete);
    guardForm(document.querySelector('form[action="/tareas/actualizar"]'), ['user_id']);
})();
</script>
<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
