<?php
/** @var string $title */
/** @var array $teamStats */
/** @var array $collaboratorStats */
/** @var string $monthLabel */
/** @var int $totalTasks */
/** @var int $totalCompleted */
/** @var float $totalHours */
/** @var float $completionRate */
/** @var string $content */
ob_start();
?>
<div class="page-header" style="display:flex;align-items:center;gap:2em;flex-wrap:wrap;">
    <h1 style="margin:0;">Seguimiento de Equipo</h1>
    <form method="get" class="month-selector" style="display:flex;align-items:center;gap:1em;">
        <label for="mes">Mes:</label>
        <input type="month" id="mes" name="mes" value="<?= htmlspecialchars($selectedMonth) ?>" onchange="this.form.submit()">
        <?php if (!empty($teams)): ?>
        <label for="team_id">Equipo:</label>
        <select id="team_id" name="team_id" onchange="this.form.submit()">
            <option value="">Todos</option>
            <?php foreach ($teams as $team): ?>
                <option value="<?= (int)$team['id'] ?>"<?= (isset($_GET['team_id']) && $_GET['team_id'] == $team['id']) ? ' selected' : '' ?>><?= htmlspecialchars($team['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
        <?php endif; ?>
    </form>
    <div class="muted">Productividad del mes <?= htmlspecialchars($monthLabel) ?></div>
</div>

<?php
// Calcular totales solo para colaboradores, filtrando por equipo si corresponde
$totalPendientes = 0;
$totalAtrasadas = 0;
$totalEnCurso = 0;
$totalTasksFicha = 0;
$totalCompletedFicha = 0;
$totalHoursFicha = 0.0;
$totalRateSum = 0.0;
$totalRateCount = 0;
$selectedTeamId = isset($_GET['team_id']) && $_GET['team_id'] !== '' ? (int)$_GET['team_id'] : null;
$filteredCollaborators = [];
if (!empty($collaboratorStats)) {
    foreach ($collaboratorStats as $col) {
        if ($selectedTeamId) {
            if (isset($col['team_ids']) && is_array($col['team_ids']) && !in_array($selectedTeamId, $col['team_ids'], true)) {
                continue;
            }
        }
        $filteredCollaborators[] = $col;
        $totalPendientes += $col['pendientes'] ?? 0;
        $totalAtrasadas += $col['atrasadas'] ?? 0;
        $totalEnCurso += $col['encurso'] ?? 0;
        $totalTasksFicha += $col['total'] ?? 0;
        $totalCompletedFicha += $col['terminadas'] ?? 0;
        $totalHoursFicha += $col['horas'] ?? 0;
        $totalRateSum += $col['cumplimiento'] ?? 0;
        $totalRateCount++;
    }
}
$completionRateFicha = $totalRateCount > 0 ? round($totalRateSum / $totalRateCount, 1) : 0;
?>
<div class="summary-grid" style="display:flex;gap:1em;flex-wrap:nowrap;justify-content:space-between;align-items:flex-start;margin-bottom:0.3em;overflow-x:auto;">
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;background:#ffeaea;border:1px solid #c00;color:#c00;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">CRÍTICAS</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars((string) $totalCritical) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">TAREAS</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars((string) $totalTasksFicha) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">TERMINADAS</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars((string) $totalCompletedFicha) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">PENDIENTES</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars((string) $totalPendientes) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">ATRASADAS</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars((string) $totalAtrasadas) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">EN CURSO</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars((string) $totalEnCurso) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">CUMPLIMIENTO</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars(number_format($completionRateFicha, 1)) ?>%</p>
    </div>
    <!-- Línea de tareas -->
</div>
<div class="summary-grid" style="display:flex;gap:1em;flex-wrap:nowrap;justify-content:space-between;align-items:flex-start;margin-bottom:2em;overflow-x:auto;">
    <!-- Línea de horas -->
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;background:#ffeaea;border:1px solid #c00;color:#c00;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">CRÍTICAS (H)</h3>
        <p style="font-size:1.1em;margin:0;line-height:1.2;white-space:nowrap;"><?= htmlspecialchars(number_format($totalCritical * ($totalHoursFicha / max($totalTasksFicha,1)), 1)) ?> h</p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">TAREAS (H)</h3>
           <p style="font-size:0.95em;margin:0;line-height:1.1;white-space:nowrap;"><?= htmlspecialchars((string) $totalCritical) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">TERMINADAS (H)</h3>
           <p style="font-size:0.95em;margin:0;line-height:1.1;white-space:nowrap;"><?= htmlspecialchars((string) $totalTasksFicha) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">PENDIENTES (H)</h3>
           <p style="font-size:0.95em;margin:0;line-height:1.1;white-space:nowrap;"><?= htmlspecialchars((string) $totalCompletedFicha) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">ATRASADAS (H)</h3>
           <p style="font-size:0.95em;margin:0;line-height:1.1;white-space:nowrap;"><?= htmlspecialchars((string) $totalPendientes) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">EN CURSO (H)</h3>
           <p style="font-size:0.95em;margin:0;line-height:1.1;white-space:nowrap;"><?= htmlspecialchars((string) $totalAtrasadas) ?></p>
    </div>
    <div class="summary-card" style="flex:1 1 0;min-width:120px;text-align:center;padding:0.5em 0;">
        <h3 style="font-size:0.85em;margin:0;line-height:1;">CUMPLIMIENTO (H)</h3>
           <p style="font-size:0.95em;margin:0;line-height:1.1;white-space:nowrap;"><?= htmlspecialchars((string) $totalEnCurso) ?></p>
    </div>
</div>
</div>
           <p style="font-size:0.95em;margin:0;line-height:1.1;white-space:nowrap;"><?= htmlspecialchars(number_format($completionRateFicha, 1)) ?>%</p>
<section class="card-block">
    <div class="card-header">
        <h2>Resumen</h2>
    </div>
    <div class="table-wrap">
        <table class="table table-compact">
            <thead>
                <tr>
                    <th>Colaborador</th>
                    <th>Rol</th>
                    <th class="table-center">Tareas</th>
                    <th class="table-center">Terminadas</th>
                    <th class="table-center">Pendientes</th>
                    <th class="table-center">Atrasadas</th>
                    <th class="table-center">En curso</th>
                       <th class="table-center" style="color:#c00;">Críticas</th>
                    <th class="table-center">Cumplimiento</th>
                    <th class="table-center">Horas</th>
                    <th class="table-center">Ver</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($filteredCollaborators)): ?>
                    <tr>
                        <td colspan="6" class="muted">No hay colaboradores disponibles.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($filteredCollaborators as $collaborator): ?>
                        <tr>
                            <td><?= htmlspecialchars($collaborator['nombre']) ?></td>
                            <td><?= htmlspecialchars($collaborator['rol']) ?></td>
                            <td class="table-center"><?= htmlspecialchars((string) $collaborator['total']) ?></td>
                            <td class="table-center"><?= htmlspecialchars((string) $collaborator['terminadas']) ?></td>
                            <td class="table-center"><?= htmlspecialchars((string) ($collaborator['pendientes'] ?? 0)) ?></td>
                            <td class="table-center"><?= htmlspecialchars((string) ($collaborator['atrasadas'] ?? 0)) ?></td>
                            <td class="table-center"><?= htmlspecialchars((string) ($collaborator['encurso'] ?? 0)) ?></td>
                               <td class="table-center" style="font-weight:bold;color:#c00;">
                                   <?= htmlspecialchars((string) ($collaborator['criticas'] ?? 0)) ?>
                               </td>
                            <td class="table-center"><?= htmlspecialchars(number_format((float) $collaborator['cumplimiento'], 1)) ?>%</td>
                            <td class="table-center"><?= htmlspecialchars(number_format((float) $collaborator['horas'], 1)) ?> h</td>
                            <td class="table-center">
                                <a href="/tareas/revision?user_id=<?= urlencode($collaborator['id']) ?>&mes=<?= urlencode($selectedMonth) ?>" title="Ver tareas y actividades">
                                    <span style="font-size:1.2em;" aria-label="Ver tareas">🔍</span>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>


<script>
(() => {
    const selector = document.getElementById('productivityView');
    if (!selector) {
        return;
    }
    const panels = document.querySelectorAll('.view-panel');
    const toggle = () => {
        const value = selector.value;
        panels.forEach((panel) => {
            panel.classList.toggle('is-hidden', panel.dataset.view !== value);
        });
    };
    selector.addEventListener('change', toggle);
    toggle();
})();
</script>

<div style="margin-top:3em; padding-top:2em; border-top:2px solid #e0e0e0;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5em;">
        <h2 style="font-size:1.2em; margin:0;">Evolutivo por colaborador</h2>
        <div style="display:flex; gap:1em; align-items:center;">
            <label for="periodoGrafico" style="font-weight:bold;">Período:</label>
            <select id="periodoGrafico" style="padding:0.5em; border:1px solid #ddd; border-radius:4px;">
                <option value="acumulativo">Últimos 6 meses (acumulativo)</option>
                <option value="mes_actual">Mes seleccionado (<?= htmlspecialchars($selectedMonth) ?>)</option>
            </select>
        </div>
    </div>
    <div style="display: flex; gap: 2em; flex-wrap: wrap; justify-content: center;">
        <div style="flex: 1 1 45%; min-width: 500px; max-width: 650px;">
            <h3 style="font-size:1em; margin-bottom:0.5em; text-align:center;">Total de tareas</h3>
            <div style="position: relative; height: 350px;">
                <canvas id="chartTareasColaboradores"></canvas>
            </div>
        </div>
        <div style="flex: 1 1 45%; min-width: 500px; max-width: 650px;">
            <h3 style="font-size:1em; margin-bottom:0.5em; text-align:center;">Total de horas</h3>
            <div style="position: relative; height: 350px;">
                <canvas id="chartHorasColaboradores"></canvas>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const meses = <?= json_encode($months ?? []) ?>;
    const tasksByUser = <?= json_encode($tasksByUserByMonth ?? []) ?>;
    const hoursByUser = <?= json_encode($hoursByUserByMonth ?? []) ?>;
    const tasksByUserCurrentMonth = <?= json_encode($tasksByUserCurrentMonth ?? []) ?>;
    const hoursByUserCurrentMonth = <?= json_encode($hoursByUserCurrentMonth ?? []) ?>;
    const colaboradores = <?= json_encode(array_map(function($col) { 
        return ['id' => $col['id'], 'nombre' => $col['nombre']]; 
    }, $collaboratorStats ?? [])) ?>;

    if (typeof Chart === 'undefined' || !colaboradores || colaboradores.length === 0) {
        return;
    }

    // Colores dinámicos para cada colaborador
    const colors = [
        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', 
        '#858796', '#5a5c69', '#2e59d9', '#17a673', '#2c9faf'
    ];

    let chartTareas = null;
    let chartHoras = null;

    function prepararDatos(periodo) {
        const colaboradorLabels = [];
        const tareasData = [];
        const horasData = [];

        colaboradores.forEach(col => {
            const userId = col.id;
            let totalTareas = 0;
            let totalHoras = 0;

            if (periodo === 'acumulativo') {
                // Sumar últimos 6 meses
                meses.forEach(mes => {
                    totalTareas += (tasksByUser[userId] && tasksByUser[userId][mes]) ? Number(tasksByUser[userId][mes]) : 0;
                    totalHoras += (hoursByUser[userId] && hoursByUser[userId][mes]) ? Number(hoursByUser[userId][mes]) : 0;
                });
            } else {
                // Mes actual
                totalTareas = tasksByUserCurrentMonth[userId] || 0;
                totalHoras = hoursByUserCurrentMonth[userId] || 0;
            }

            colaboradorLabels.push(col.nombre);
            tareasData.push(totalTareas);
            horasData.push(totalHoras);
        });

        const backgroundColors = colaboradorLabels.map((_, i) => colors[i % colors.length]);
        const borderColors = backgroundColors;

        // Calcular máximos con margen +3
        const maxTareas = Math.max(...tareasData);
        const maxTareasChart = maxTareas + 3;
        
        const maxHoras = Math.max(...horasData);
        const maxHorasChart = maxHoras + 3;

        return {
            colaboradorLabels,
            tareasData,
            horasData,
            backgroundColors,
            borderColors,
            maxTareasChart,
            maxHorasChart
        };
    }

    function crearGraficos(periodo) {
        const datos = prepararDatos(periodo);

        // Destruir gráficos existentes
        if (chartTareas) chartTareas.destroy();
        if (chartHoras) chartHoras.destroy();

        // Gráfico de Tareas
        const canvasTareas = document.getElementById('chartTareasColaboradores');
        if (canvasTareas) {
            try {
                const ctxTareas = canvasTareas.getContext('2d');
                chartTareas = new Chart(ctxTareas, {
                    type: 'bar',
                    data: {
                        labels: datos.colaboradorLabels,
                        datasets: [{
                            label: 'Total tareas',
                            data: datos.tareasData,
                            backgroundColor: datos.backgroundColors,
                            borderColor: datos.borderColors,
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        plugins: { 
                            legend: { 
                                display: false
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return 'Tareas: ' + context.parsed.x;
                                    }
                                }
                            },
                            datalabels: {
                                display: true,
                                align: 'end',
                                anchor: 'end',
                                color: '#000',
                                font: {
                                    weight: 'bold',
                                    size: 12
                                },
                                formatter: function(value) {
                                    return value;
                                }
                            }
                        },
                        scales: { 
                            x: { 
                                beginAtZero: true,
                                max: datos.maxTareasChart,
                                ticks: {
                                    precision: 0,
                                    stepSize: 1
                                },
                                title: {
                                    display: true,
                                    text: 'Cantidad de tareas'
                                }
                            },
                            y: {
                                title: {
                                    display: true,
                                    text: 'Colaborador'
                                }
                            }
                        }
                    },
                    plugins: [ChartDataLabels]
                });
            } catch (error) {
                console.error('Error creando gráfico de tareas:', error);
            }
        }

        // Gráfico de Horas
        const canvasHoras = document.getElementById('chartHorasColaboradores');
        if (canvasHoras) {
            try {
                const ctxHoras = canvasHoras.getContext('2d');
                chartHoras = new Chart(ctxHoras, {
                    type: 'bar',
                    data: {
                        labels: datos.colaboradorLabels,
                        datasets: [{
                            label: 'Total horas',
                            data: datos.horasData,
                            backgroundColor: datos.backgroundColors,
                            borderColor: datos.borderColors,
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        indexAxis: 'y',
                        plugins: { 
                            legend: { 
                                display: false
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return 'Horas: ' + context.parsed.x.toFixed(1);
                                    }
                                }
                            },
                            datalabels: {
                                display: true,
                                align: 'end',
                                anchor: 'end',
                                color: '#000',
                                font: {
                                    weight: 'bold',
                                    size: 12
                                },
                                formatter: function(value) {
                                    return value.toFixed(1);
                                }
                            }
                        },
                        scales: { 
                            x: { 
                                beginAtZero: true,
                                max: datos.maxHorasChart,
                                ticks: {
                                    precision: 1
                                },
                                title: {
                                    display: true,
                                    text: 'Total de horas'
                                }
                            },
                            y: {
                                title: {
                                    display: true,
                                    text: 'Colaborador'
                                }
                            }
                        }
                    },
                    plugins: [ChartDataLabels]
                });
            } catch (error) {
                console.error('Error creando gráfico de horas:', error);
            }
        }
    }

    // Crear gráficos iniciales
    crearGraficos('acumulativo');

    // Listener para cambio de período
    const selectorPeriodo = document.getElementById('periodoGrafico');
    if (selectorPeriodo) {
        selectorPeriodo.addEventListener('change', function() {
            crearGraficos(this.value);
        });
    }
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
