<?php
/** @var string $title */
/** @var array $categories */
/** @var array $classifications */
/** @var string|null $error */
ob_start();
$formatHours = function ($value): string {
    $decimal = (float) $value;
    $hours = (int) floor($decimal);
    $minutes = (int) round(($decimal - $hours) * 60);
    if ($minutes === 60) {
        $hours += 1;
        $minutes = 0;
    }
    return sprintf('%02d:%02d', $hours, $minutes);
};
$formatPercent = function ($done, $total): string {
    $total = (int) $total;
    if ($total <= 0) {
        return '0%';
    }
    $done = (int) $done;
    $percent = (int) round(($done / $total) * 100);
    return $percent . '%';
};
$missingDateCount = 0;
foreach ($categories as $category) {
    $missingDateCount += (int) ($category['sin_fecha'] ?? 0);
}
?>
<div class="page-header">
    <h1>Gestion de tarea</h1>
</div>
<?php if (! empty($error)): ?>
    <div class="alert"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="hero-actions">
    <button type="button" class="btn" data-open-modal="categoryModal">Nueva actividad</button>
</div>

<div class="stack-grid">
    <div class="card-block">
        <h2>Actividades</h2>
        <div class="filter-row">
            <div class="filter-bar">
                <label for="categoryFilter">Filtrar actividades</label>
                <input type="text" id="categoryFilter" placeholder="Buscar por nombre" autocomplete="off">
            </div>
            <div class="filter-bar">
                <label for="classificationFilter">Clasificacion</label>
                <select id="classificationFilter">
                    <option value="">Todas</option>
                    <?php foreach ($classifications as $classification): ?>
                        <option value="<?= (int) $classification['id'] ?>"><?= htmlspecialchars($classification['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <?php if (empty($categories)): ?>
            <p class="muted">No hay actividades registradas.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Actividad</th>
                        <th>Clasificacion</th>
                        <th class="table-center">Total</th>
                        <th class="table-center">Pendientes</th>
                        <th class="table-center">En curso</th>
                        <th class="table-center">Atrasadas</th>
                        <th class="table-center">Terminadas</th>
                        <th class="table-center">Horas</th>
                        <th class="table-center">Avance</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td>
                                <?= htmlspecialchars($category['nombre']) ?>
                                <?php if ((int) ($category['sin_fecha'] ?? 0) > 0): ?>
                                    <span class="warn-icon" title="Tiene tareas sin fecha de compromiso" aria-label="Tiene tareas sin fecha de compromiso">
                                        <svg viewBox="0 0 16 16" aria-hidden="true">
                                            <path fill="currentColor" d="M8 1.2 15.4 14H.6L8 1.2zm0 3.1L3.1 12.4h9.8L8 4.3zm.9 2.6v3.8H7.1V6.9h1.8zm0 4.6v1.8H7.1v-1.8h1.8z"/>
                                        </svg>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td data-classification-id="<?= (int) ($category['classification_id'] ?? 0) ?>">
                                <?= htmlspecialchars($category['clasificacion_nombre'] ?? '-') ?>
                            </td>
                            <td class="table-center"><?= htmlspecialchars($category['tareas'] ?? 0) ?></td>
                            <td class="table-center"><?= htmlspecialchars($category['pendientes'] ?? 0) ?></td>
                            <td class="table-center"><?= htmlspecialchars($category['en_curso'] ?? 0) ?></td>
                            <td class="table-center"><?= htmlspecialchars($category['atrasadas'] ?? 0) ?></td>
                            <td class="table-center"><?= htmlspecialchars($category['terminadas'] ?? 0) ?></td>
                            <td class="table-center"><?= htmlspecialchars($formatHours($category['horas_total'] ?? 0)) ?></td>
                            <td class="table-center"><?= htmlspecialchars($formatPercent($category['terminadas'] ?? 0, $category['tareas'] ?? 0)) ?></td>
                            <td>
                                <div class="table-actions">
                                    <button type="button" class="btn btn-secondary btn-small btn-icon" data-open-modal="tasksModal" data-category-id="<?= (int) $category['id'] ?>" data-category-name="<?= htmlspecialchars($category['nombre']) ?>" title="Ver tareas" aria-label="Ver tareas">
                                        <svg viewBox="0 0 16 16" aria-hidden="true">
                                            <path fill="currentColor" d="M8 3.2c3.4 0 6.1 2.3 7.2 4.8-1.1 2.5-3.8 4.8-7.2 4.8S1.9 10.5.8 8C1.9 5.5 4.6 3.2 8 3.2zm0 1.6c-2.4 0-4.5 1.5-5.4 3.2.9 1.7 3 3.2 5.4 3.2s4.5-1.5 5.4-3.2c-.9-1.7-3-3.2-5.4-3.2zm0 1.6a2.4 2.4 0 1 1 0 4.8 2.4 2.4 0 0 1 0-4.8z"/>
                                        </svg>
                                    </button>
                                    <button type="button" class="btn btn-secondary btn-small btn-icon" data-open-modal="copyModal" data-source-category-id="<?= (int) $category['id'] ?>" data-source-category-name="<?= htmlspecialchars($category['nombre']) ?>" title="Copiar tareas" aria-label="Copiar tareas">
                                        <svg viewBox="0 0 16 16" aria-hidden="true">
                                            <path fill="currentColor" d="M5 2a2 2 0 0 0-2 2v6h1.6V4a.4.4 0 0 1 .4-.4h6V2H5zm3 3a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h5a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H8zm0 1.6h5a.4.4 0 0 1 .4.4v7a.4.4 0 0 1-.4.4H8a.4.4 0 0 1-.4-.4V7a.4.4 0 0 1 .4-.4z"/>
                                        </svg>
                                    </button>
                                    <button type="button" class="btn btn-secondary btn-small" data-open-modal="categoryModal" data-category-id="<?= (int) $category['id'] ?>" data-category-name="<?= htmlspecialchars($category['nombre']) ?>" data-category-classification="<?= (int) ($category['classification_id'] ?? 0) ?>" title="Editar actividad">Editar</button>
                                    <form method="post" action="/gestion-tareas/categorias/eliminar" class="inline" onsubmit="return confirm('Eliminar actividad?');">
                                        <input type="hidden" name="id" value="<?= (int) $category['id'] ?>">
                                        <button type="submit" class="btn btn-danger btn-small" title="Eliminar actividad">Eliminar</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</div>
<div class="modal" id="categoryModal" data-modal>
    <div class="modal-overlay" data-close-modal></div>
    <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="categoryModalTitle">
        <div class="modal-header">
            <h2 id="categoryModalTitle">Nueva actividad</h2>
            <button type="button" class="btn btn-secondary btn-small" data-close-modal>Cerrar</button>
        </div>
        <form method="post" action="/gestion-tareas/categorias/crear" class="form" data-category-form>
            <input type="hidden" name="id" value="">
            <label>Nombre</label>
            <input type="text" name="nombre" required>
            <?php if ($isAdmin): ?>
                <label>Clasificacion</label>
                <select name="classification_id">
                    <option value="">Sin clasificacion</option>
                    <?php foreach ($classifications as $classification): ?>
                        <option value="<?= (int) $classification['id'] ?>"><?= htmlspecialchars($classification['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            <?php else: ?>
                <input type="hidden" name="classification_id" value="">
            <?php endif; ?>
            <div class="form-actions">
                <button type="submit" class="btn">Guardar</button>
            </div>
        </form>
    </div>
</div>
<div class="modal" id="tasksModal" data-modal>
    <div class="modal-overlay" data-close-modal></div>
    <div class="modal-card modal-card-xl" role="dialog" aria-modal="true" aria-labelledby="tasksModalTitle">
        <div class="modal-header">
            <h2 id="tasksModalTitle">Tareas de actividad</h2>
            <button type="button" class="btn btn-secondary btn-small" data-close-modal>Cerrar</button>
        </div>
        <div class="hero-actions">
            <button type="button" class="btn" data-open-modal="taskQuickModal" id="openTaskQuick">Nueva tarea</button>
        </div>
        <div class="filter-bar">
            <label for="tasksModalFilter">Filtrar tareas</label>
            <input type="text" id="tasksModalFilter" placeholder="Buscar por titulo, asignado o estado" autocomplete="off">
        </div>
        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Titulo</th>
                        <th>Asignado</th>
                        <th>Estado</th>
                        <th>Compromiso</th>
                        <th>Horas</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="tasksModalBody"></tbody>
            </table>
        </div>
    </div>
</div>
<div class="modal" id="taskQuickModal" data-modal>
    <div class="modal-overlay" data-close-modal></div>
    <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="taskQuickModalTitle">
        <div class="modal-header">
            <h2 id="taskQuickModalTitle">Nueva tarea</h2>
            <button type="button" class="btn btn-secondary btn-small" data-close-modal>Cerrar</button>
        </div>
        <form method="post" action="/tareas/crear" class="form" id="taskQuickForm" data-auth-user-id="<?= (int) ($authUser['id'] ?? 0) ?>">
            <input type="hidden" name="category_id" value="">
            <input type="hidden" name="return_url" value="">
            <label>Titulo</label>
            <input type="text" name="titulo" required>
            <label>Asignar a</label>
            <input type="text" name="user_label" value="<?= htmlspecialchars($authUser['nombre'] ?? '') ?>" readonly>
            <input type="hidden" name="user_id" value="<?= (int) ($authUser['id'] ?? 0) ?>">
            <label>Fecha compromiso estimada</label>
            <input type="date" name="fecha_compromiso" required>
            <label>Prioridad</label>
            <select name="prioridad" required>
                <option value="baja">Baja</option>
                <option value="media" selected>Media</option>
                <option value="alta">Alta</option>
                <option value="critica">Critica</option>
            </select>
            <label>Estado</label>
            <select name="estado" required>
                <option value="pendiente" selected>Pendiente</option>
                <option value="en_curso">En curso</option>
                <option value="congelada">Congelada</option>
                <option value="atrasada">Atrasada</option>
                <option value="terminada">Terminada</option>
            </select>
            <div class="form-actions">
                <button type="submit" class="btn">Guardar tarea</button>
            </div>
        </form>
    </div>
</div>
<div class="modal" id="copyModal" data-modal>
    <div class="modal-overlay" data-close-modal></div>
    <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="copyModalTitle">
        <div class="modal-header">
            <h2 id="copyModalTitle">Copiar tareas entre actividades</h2>
            <button type="button" class="btn btn-secondary btn-small" data-close-modal>Cerrar</button>
        </div>
        <form method="post" action="/tareas/categorias/copiar" class="form" data-copy-form>
            <label>Actividad origen</label>
            <input type="text" name="source_category_label" readonly>
            <input type="hidden" name="source_category_id" value="">

            <div class="autocomplete">
                <label>Actividad destino</label>
                <input type="text" name="target_category_name" data-source="task-categories" autocomplete="off" required>
                <input type="hidden" name="target_category_id" value="">
                <div class="autocomplete-results"></div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn">Copiar tareas</button>
            </div>
        </form>
    </div>
</div>
<script>
(() => {
    const setupModal = (modalId, onOpen) => {
        const modal = document.getElementById(modalId);
        if (!modal) {
            return null;
        }
        const openButtons = document.querySelectorAll(`[data-open-modal="${modalId}"]`);
        const closeTargets = modal.querySelectorAll('[data-close-modal]');
        const openModal = (event) => {
            modal.classList.add('is-open');
            if (onOpen) {
                onOpen(event, modal);
            }
        };
        const closeModal = () => {
            modal.classList.remove('is-open');
        };

        openButtons.forEach((btn) => btn.addEventListener('click', openModal));
        closeTargets.forEach((btn) => btn.addEventListener('click', closeModal));
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                closeModal();
            }
        });

        return { openModal, closeModal };
    };

    setupModal('categoryModal', (event, modal) => {
        const form = modal.querySelector('[data-category-form]');
        const idInput = form?.querySelector('input[name="id"]');
        const input = modal.querySelector('input[name="nombre"]');
        const classificationSelect = modal.querySelector('select[name="classification_id"]');
        const button = event?.currentTarget;
        const categoryId = button?.getAttribute('data-category-id') || '';
        const categoryName = button?.getAttribute('data-category-name') || '';
        const classificationId = button?.getAttribute('data-category-classification') || '';
        if (form && idInput) {
            if (categoryId) {
                form.action = '/gestion-tareas/categorias/actualizar';
                idInput.value = categoryId;
            } else {
                form.action = '/gestion-tareas/categorias/crear';
                idInput.value = '';
            }
        }
        if (input) {
            input.value = categoryName;
            input.focus();
        }
        if (classificationSelect) {
            classificationSelect.value = classificationId || '';
        }
    });


    const tasksModal = setupModal('tasksModal', (event, modal) => {
        const button = event?.currentTarget;
        const categoryId = button?.getAttribute('data-category-id') || '';
        const categoryName = button?.getAttribute('data-category-name') || '';
        const title = modal.querySelector('#tasksModalTitle');
        if (title) {
            title.textContent = `Tareas: ${categoryName}`;
        }
        modal.dataset.categoryId = categoryId;
        modal.dataset.returnUrl = `/gestion-tareas?open_categoria_id=${encodeURIComponent(categoryId)}`;
        const body = modal.querySelector('#tasksModalBody');
        if (body) {
            body.innerHTML = '<tr><td colspan="6" class="muted">Cargando...</td></tr>';
        }
        const formCategory = document.querySelector('#taskQuickForm input[name="category_id"]');
        const formReturn = document.querySelector('#taskQuickForm input[name="return_url"]');
        if (formCategory) {
            formCategory.value = categoryId;
        }
        if (formReturn) {
            formReturn.value = modal.dataset.returnUrl || '';
        }
        const returnUrl = modal.dataset.returnUrl || '';
        fetch(`/gestion-tareas/categorias/tareas?categoria_id=${encodeURIComponent(categoryId)}`)
            .then((res) => (res.ok ? res.json() : []))
            .then((items) => {
                if (!body) {
                    return;
                }
                if (!items.length) {
                    body.innerHTML = '<tr><td colspan="6" class="muted">No hay tareas en esta actividad.</td></tr>';
                    return;
                }
                body.innerHTML = items
                    .map((task) => {
                        return `
                            <tr>
                                <td>${task.titulo ?? ''}</td>
                                <td>${task.asignado_nombre ?? ''}</td>
                                <td>${task.estado ?? ''}</td>
                                <td>${formatDate(task.fecha_compromiso)}</td>
                                <td>${formatHours(task.total_horas)}</td>
                                <td>
                                    <div class="table-actions">
                                        <a href="/tareas/detalle?id=${task.id}&return=${encodeURIComponent(returnUrl)}" class="btn btn-secondary btn-small" title="Ver detalle de la tarea">Detalle</a>
                                        <a href="/tareas/editar?id=${task.id}&return=${encodeURIComponent(returnUrl)}" class="btn btn-secondary btn-small" title="Editar tarea">Editar</a>
                                        <form method="post" action="/tareas/eliminar" class="inline" onsubmit="return confirm('Eliminar tarea?');">
                                            <input type="hidden" name="task_id" value="${task.id}">
                                            <input type="hidden" name="return_url" value="${returnUrl}">
                                            <button type="submit" class="btn btn-danger btn-small" title="Eliminar tarea">Eliminar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        `;
                    })
                    .join('');
            });
    });

    const taskQuickModal = setupModal('taskQuickModal', (_, modal) => {
        const tasksModalEl = document.getElementById('tasksModal');
        const formCategory = document.querySelector('#taskQuickForm input[name="category_id"]');
        const formReturn = document.querySelector('#taskQuickForm input[name="return_url"]');
        const userIdInput = document.querySelector('#taskQuickForm input[name="user_id"]');
        const authUserId = document.querySelector('#taskQuickForm')?.dataset?.authUserId || '';
        if (formCategory && tasksModalEl?.dataset?.categoryId) {
            formCategory.value = tasksModalEl.dataset.categoryId;
        }
        if (formReturn && tasksModalEl?.dataset?.returnUrl) {
            formReturn.value = tasksModalEl.dataset.returnUrl;
        }
        if (userIdInput && authUserId) {
            userIdInput.value = authUserId;
        }
        const input = modal.querySelector('input[name="titulo"]');
        if (input) {
            input.focus();
        }
    });

    const openTaskQuick = document.getElementById('openTaskQuick');
    if (openTaskQuick && taskQuickModal) {
        openTaskQuick.addEventListener('click', () => {
            taskQuickModal.openModal();
        });
    }

    setupModal('copyModal', (event, modal) => {
        const button = event?.currentTarget;
        const sourceId = button?.getAttribute('data-source-category-id') || '';
        const sourceName = button?.getAttribute('data-source-category-name') || '';
        const idInput = modal.querySelector('input[name="source_category_id"]');
        const labelInput = modal.querySelector('input[name="source_category_label"]');
        modal.dataset.sourceCategoryId = sourceId;
        modal.dataset.sourceCategoryName = sourceName;
        if (idInput) {
            idInput.value = sourceId;
        }
        if (labelInput) {
            labelInput.value = sourceName;
        }
    });

    const debounce = (fn, wait = 200) => {
        let t;
        return (...args) => {
            clearTimeout(t);
            t = setTimeout(() => fn(...args), wait);
        };
    };

    const initAutocomplete = (wrapper) => {
        const input = wrapper.querySelector('input[type="text"]');
        const hidden = wrapper.querySelector('input[type="hidden"]');
        const results = wrapper.querySelector('.autocomplete-results');
        if (!input || !hidden || !results) {
            return;
        }

        const fetchItems = async (term, limit = 15) => {
            const params = new URLSearchParams({ q: term, limit });
            const res = await fetch(`/tareas/buscar-categorias?${params.toString()}`);
            if (!res.ok) {
                return [];
            }
            return res.json();
        };

        const renderResults = (items) => {
            results.innerHTML = '';
            if (!items.length) {
                return;
            }
            items.forEach((item) => {
                const row = document.createElement('div');
                row.className = 'autocomplete-item';
                row.textContent = item.nombre;
                row.addEventListener('click', () => {
                    input.value = row.textContent;
                    hidden.value = item.id;
                    results.innerHTML = '';
                });
                results.appendChild(row);
            });
        };

        const handle = debounce(async () => {
            const term = input.value.trim();
            hidden.value = '';
            if (term.length < 2) {
                results.innerHTML = '';
                return;
            }
            const items = await fetchItems(term);
            renderResults(items);
        });

        input.addEventListener('input', handle);
        document.addEventListener('click', (event) => {
            if (!wrapper.contains(event.target)) {
                results.innerHTML = '';
            }
        });
    };

    const normalizeText = (value) => {
        return value
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();
    };

    const guardForm = (form, fields) => {
        if (!form) {
            return;
        }
        form.addEventListener('submit', (event) => {
            for (const name of fields) {
                if (!form.querySelector(`input[name="${name}"]`)?.value) {
                    event.preventDefault();
                    alert('Selecciona un valor desde la lista.');
                    return;
                }
            }
        });
    };

    const categoryFilter = document.getElementById('categoryFilter');
    const classificationFilter = document.getElementById('classificationFilter');
    if (categoryFilter) {
        const rows = Array.from(document.querySelectorAll('table tbody tr'));
        const handle = debounce(() => {
            const term = categoryFilter.value.trim().toLowerCase();
            const classificationId = classificationFilter?.value || '';
            rows.forEach((row) => {
                const haystack = row.textContent.toLowerCase();
                const rowClassification = row.querySelector('[data-classification-id]')?.getAttribute('data-classification-id') || '';
                const matchesText = haystack.includes(term);
                const matchesClassification = !classificationId || classificationId === rowClassification;
                row.style.display = matchesText && matchesClassification ? '' : 'none';
            });
        });
        categoryFilter.addEventListener('input', handle);
        classificationFilter?.addEventListener('change', handle);
    }

    document.querySelectorAll('#copyModal .autocomplete').forEach(initAutocomplete);

    const copyForm = document.querySelector('form[data-copy-form]');
    if (copyForm) {
        copyForm.addEventListener('submit', async (event) => {
            const copyModal = document.getElementById('copyModal');
            const sourceIdInput = copyForm.querySelector('input[name="source_category_id"]');
            const sourceLabelInput = copyForm.querySelector('input[name="source_category_label"]');
            let sourceId = sourceIdInput?.value;
            if (!sourceId && copyModal?.dataset.sourceCategoryId) {
                sourceId = copyModal.dataset.sourceCategoryId;
                if (sourceIdInput) {
                    sourceIdInput.value = sourceId;
                }
            }
            if (!sourceId && sourceLabelInput?.value && copyModal?.dataset.sourceCategoryName) {
                sourceId = copyModal.dataset.sourceCategoryId || '';
            }
            if (!sourceId) {
                event.preventDefault();
                alert('Selecciona la actividad de origen desde la lista de actividades.');
                return;
            }
            const targetIdInput = copyForm.querySelector('input[name="target_category_id"]');
            const targetNameInput = copyForm.querySelector('input[name="target_category_name"]');
            const targetName = targetNameInput?.value?.trim() ?? '';
            if (!targetName) {
                alert('Selecciona la actividad destino desde la lista.');
                return;
            }
            if (targetIdInput?.value) {
                return;
            }
        });
    }

    const formatDate = (value) => {
        if (!value) {
            return '-';
        }
        const parts = value.split('-');
        if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        return value;
    };

    const formatHours = (value) => {
        const decimal = parseFloat(value || 0);
        let hours = Math.floor(decimal);
        let minutes = Math.round((decimal - hours) * 60);
        if (minutes === 60) {
            hours += 1;
            minutes = 0;
        }
        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
    };


    const openCategoryId = new URLSearchParams(window.location.search).get('open_categoria_id');
    if (openCategoryId) {
        const opener = document.querySelector(`[data-open-modal="tasksModal"][data-category-id="${openCategoryId}"]`);
        if (opener && tasksModal) {
            tasksModal.openModal({ currentTarget: opener });
        }
    }

    const tasksFilter = document.getElementById('tasksModalFilter');
    if (tasksFilter) {
        const handle = debounce(() => {
            const term = tasksFilter.value.trim().toLowerCase();
            document.querySelectorAll('#tasksModalBody tr').forEach((row) => {
                const haystack = row.textContent.toLowerCase();
                row.style.display = haystack.includes(term) ? '' : 'none';
            });
        });
        tasksFilter.addEventListener('input', handle);
    }
})();
</script>
<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
