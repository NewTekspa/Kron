<?php

namespace App\Models;

use App\Core\Database;
use App\Models\Team;

class User
{
    private static function db()
    {
        $config = require __DIR__ . '/../../config/database.php';
        return Database::connection($config);
    }

    public static function findById(int $id): ?array
    {
        $stmt = self::db()->prepare('SELECT * FROM KRON_USERS WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();

        return $row ?: null;
    }

    public static function findWithRole(int $id): ?array
    {
        $sql = 'SELECT u.*, ur.role_id AS rol_id
                FROM KRON_USERS u
                LEFT JOIN KRON_USER_ROLES ur ON ur.user_id = u.id
                WHERE u.id = :id
                LIMIT 1';
        $stmt = self::db()->prepare($sql);
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();

        return $row ?: null;
    }

    public static function findByEmail(string $email): ?array
    {
        $stmt = self::db()->prepare('SELECT * FROM KRON_USERS WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => $email]);
        $row = $stmt->fetch();

        return $row ?: null;
    }

    public static function emailExists(string $email, ?int $ignoreId = null): bool
    {
        if ($ignoreId) {
            $stmt = self::db()->prepare('SELECT 1 FROM KRON_USERS WHERE email = :email AND id <> :id LIMIT 1');
            $stmt->execute(['email' => $email, 'id' => $ignoreId]);
        } else {
            $stmt = self::db()->prepare('SELECT 1 FROM KRON_USERS WHERE email = :email LIMIT 1');
            $stmt->execute(['email' => $email]);
        }

        return (bool) $stmt->fetchColumn();
    }

    public static function allWithRole(): array
    {
        $sql = 'SELECT u.*, r.nombre AS rol_nombre
                FROM KRON_USERS u
                LEFT JOIN KRON_USER_ROLES ur ON ur.user_id = u.id
                LEFT JOIN KRON_ROLES r ON r.id = ur.role_id
                ORDER BY u.nombre';
        return self::db()->query($sql)->fetchAll();
    }

    public static function allWithRoleByIds(array $ids): array
    {
        if (empty($ids)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = 'SELECT u.*, r.nombre AS rol_nombre
                FROM KRON_USERS u
                LEFT JOIN KRON_USER_ROLES ur ON ur.user_id = u.id
                LEFT JOIN KRON_ROLES r ON r.id = ur.role_id
                WHERE u.id IN (' . $placeholders . ')
                ORDER BY u.nombre';
        $stmt = self::db()->prepare($sql);
        $stmt->execute(array_values($ids));

        return $stmt->fetchAll();
    }

    public static function allWithRoleVisibleTo(int $userId, string $roleName): array
    {
        if ($roleName === 'administrador') {
            return self::allWithRole();
        }

        $ids = Team::visibleUserIdsForRole($userId, $roleName);
        return self::allWithRoleByIds($ids);
    }

    public static function searchForTeam(string $term, array $roleNames = [], int $limit = 15): array
    {
        $term = trim($term);
        if ($term === '') {
            return [];
        }

        $limit = max(1, min(50, $limit));
        $like = '%' . $term . '%';
        $params = [
            'like' => $like,
            'limit' => $limit,
        ];

        $roleFilter = '';
        if (! empty($roleNames)) {
            $placeholders = [];
            foreach (array_values($roleNames) as $index => $roleName) {
                $key = 'role_' . $index;
                $placeholders[] = ':' . $key;
                $params[$key] = $roleName;
            }
            $roleFilter = ' AND r.nombre IN (' . implode(',', $placeholders) . ')';
        }

        $sql = 'SELECT u.id, u.nombre, u.email, r.nombre AS rol_nombre
                FROM KRON_USERS u
                LEFT JOIN KRON_USER_ROLES ur ON ur.user_id = u.id
                LEFT JOIN KRON_ROLES r ON r.id = ur.role_id
                WHERE u.estado = "activo" AND (u.nombre LIKE :like OR u.email LIKE :like)'
                . $roleFilter . '
                ORDER BY u.nombre
                LIMIT :limit';
        $stmt = self::db()->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue(':' . $key, $value, $key === 'limit' ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public static function searchByIds(string $term, array $ids, int $limit = 15): array
    {
        $term = trim($term);
        if ($term === '' || empty($ids)) {
            return [];
        }

        $limit = max(1, min(50, $limit));
        $like = '%' . $term . '%';
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = 'SELECT u.id, u.nombre, u.email, r.nombre AS rol_nombre
                FROM KRON_USERS u
                LEFT JOIN KRON_USER_ROLES ur ON ur.user_id = u.id
                LEFT JOIN KRON_ROLES r ON r.id = ur.role_id
                WHERE u.id IN (' . $placeholders . ')
                  AND u.estado = "activo"
                  AND (u.nombre LIKE ? OR u.email LIKE ?)
                ORDER BY u.nombre
                LIMIT ' . (int) $limit;
        $stmt = self::db()->prepare($sql);
        $params = array_values($ids);
        $params[] = $like;
        $params[] = $like;
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    public static function create(array $data): int
    {
        $stmt = self::db()->prepare('INSERT INTO KRON_USERS (nombre, email, estado, fecha_ingreso, password_hash) VALUES (:nombre, :email, :estado, :fecha_ingreso, :password_hash)');
        $stmt->execute([
            'nombre' => $data['nombre'],
            'email' => $data['email'],
            'estado' => $data['estado'],
            'fecha_ingreso' => $data['fecha_ingreso'],
            'password_hash' => $data['password_hash'],
        ]);

        return (int) self::db()->lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $stmt = self::db()->prepare('UPDATE KRON_USERS SET nombre = :nombre, email = :email, estado = :estado, fecha_ingreso = :fecha_ingreso, password_hash = :password_hash WHERE id = :id');
        $stmt->execute([
            'nombre' => $data['nombre'],
            'email' => $data['email'],
            'estado' => $data['estado'],
            'fecha_ingreso' => $data['fecha_ingreso'],
            'password_hash' => $data['password_hash'],
            'id' => $id,
        ]);
    }

    public static function updateWithoutPassword(int $id, array $data): void
    {
        $stmt = self::db()->prepare('UPDATE KRON_USERS SET nombre = :nombre, email = :email, estado = :estado, fecha_ingreso = :fecha_ingreso WHERE id = :id');
        $stmt->execute([
            'nombre' => $data['nombre'],
            'email' => $data['email'],
            'estado' => $data['estado'],
            'fecha_ingreso' => $data['fecha_ingreso'],
            'id' => $id,
        ]);
    }

    public static function deactivate(int $id): void
    {
        $stmt = self::db()->prepare('UPDATE KRON_USERS SET estado = "inactivo" WHERE id = :id');
        $stmt->execute(['id' => $id]);
    }

    public static function delete(int $id): void
    {
        $stmt = self::db()->prepare('DELETE FROM KRON_USERS WHERE id = :id');
        $stmt->execute(['id' => $id]);
    }
}
