<?php

namespace App\Models;

use App\Core\Database;

class TaskCategory
{
    private static function db()
    {
        $config = require __DIR__ . '/../../config/database.php';
        return Database::connection($config);
    }

    public static function findById(int $id): ?array
    {
        $stmt = self::db()->prepare('SELECT * FROM KRON_TASK_CATEGORIES WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();

        return $row ?: null;
    }

    public static function findByName(string $nombre): ?array
    {
        $stmt = self::db()->prepare('SELECT * FROM KRON_TASK_CATEGORIES WHERE nombre = :nombre LIMIT 1');
        $stmt->execute(['nombre' => $nombre]);
        $row = $stmt->fetch();

        return $row ?: null;
    }

    public static function findOrCreate(string $nombre, int $createdBy): int
    {
        $nombre = trim($nombre);
        if ($nombre === '') {
            return 0;
        }

        $existing = self::findByName($nombre);
        if ($existing) {
            return (int) $existing['id'];
        }

        $stmt = self::db()->prepare('INSERT INTO KRON_TASK_CATEGORIES (nombre, created_by) VALUES (:nombre, :created_by)');
        $stmt->execute([
            'nombre' => $nombre,
            'created_by' => $createdBy,
        ]);

        return (int) self::db()->lastInsertId();
    }

    public static function createWithClassification(string $nombre, int $createdBy, ?int $classificationId): int
    {
        $nombre = trim($nombre);
        if ($nombre === '') {
            return 0;
        }

        $existing = self::findByName($nombre);
        if ($existing) {
            return (int) $existing['id'];
        }

        $stmt = self::db()->prepare('INSERT INTO KRON_TASK_CATEGORIES (nombre, created_by, classification_id)
            VALUES (:nombre, :created_by, :classification_id)');
        $stmt->execute([
            'nombre' => $nombre,
            'created_by' => $createdBy,
            'classification_id' => $classificationId ?: null,
        ]);

        return (int) self::db()->lastInsertId();
    }

    public static function searchByName(string $term, int $limit = 15): array
    {
        $term = trim($term);
        if ($term === '') {
            return [];
        }

        $limit = max(1, min(50, $limit));
        $stmt = self::db()->prepare('SELECT id, nombre FROM KRON_TASK_CATEGORIES WHERE nombre LIKE :like ORDER BY nombre LIMIT :limit');
        $stmt->bindValue(':like', '%' . $term . '%');
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public static function allWithCounts(?array $userIds = null): array
    {
        $where = '';
        $params = [];
        $repeatCount = 0;
        if (is_array($userIds) && ! empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = ' AND (t.user_id IN (' . $placeholders . ') OR t.user_id IS NULL OR t.user_id = 0)';
            $params = array_values($userIds);
            $repeatCount = 7;
        }

        $sql = 'SELECT c.id, c.nombre, c.classification_id, cl.nombre AS clasificacion_nombre,
                (SELECT COUNT(*) FROM KRON_TASKS t WHERE t.category_id = c.id' . $where . ') AS tareas,
                (SELECT COUNT(*) FROM KRON_TASKS t WHERE t.category_id = c.id AND t.estado = "pendiente"' . $where . ') AS pendientes,
                (SELECT COUNT(*) FROM KRON_TASKS t WHERE t.category_id = c.id AND t.estado = "en_curso"' . $where . ') AS en_curso,
                (SELECT COUNT(*) FROM KRON_TASKS t WHERE t.category_id = c.id AND t.estado = "atrasada"' . $where . ') AS atrasadas,
                (SELECT COUNT(*) FROM KRON_TASKS t WHERE t.category_id = c.id AND t.estado = "terminada"' . $where . ') AS terminadas,
                (SELECT COUNT(*) FROM KRON_TASKS t WHERE t.category_id = c.id AND t.fecha_compromiso IS NULL' . $where . ') AS sin_fecha,
                (SELECT COALESCE(SUM(tt.horas), 0)
                 FROM KRON_TASKS t
                 LEFT JOIN KRON_TASK_TIMES tt ON tt.task_id = t.id
                 WHERE t.category_id = c.id' . $where . ') AS horas_total
                FROM KRON_TASK_CATEGORIES c
                LEFT JOIN KRON_TASK_CLASSIFICATIONS cl ON cl.id = c.classification_id
                ORDER BY c.nombre';
        $stmt = self::db()->prepare($sql);
        if ($repeatCount > 1) {
            $finalParams = [];
            for ($i = 0; $i < $repeatCount; $i++) {
                $finalParams = array_merge($finalParams, $params);
            }
            $stmt->execute($finalParams);
        } else {
            $stmt->execute($params);
        }

        return $stmt->fetchAll();
    }

    public static function updateName(int $id, string $nombre): void
    {
        $stmt = self::db()->prepare('UPDATE KRON_TASK_CATEGORIES SET nombre = :nombre WHERE id = :id');
        $stmt->execute([
            'nombre' => $nombre,
            'id' => $id,
        ]);
    }

    public static function updateDetails(int $id, string $nombre, ?int $classificationId): void
    {
        $stmt = self::db()->prepare('UPDATE KRON_TASK_CATEGORIES
            SET nombre = :nombre,
                classification_id = :classification_id
            WHERE id = :id');
        $stmt->execute([
            'nombre' => $nombre,
            'classification_id' => $classificationId ?: null,
            'id' => $id,
        ]);
    }

    public static function delete(int $id): void
    {
        $stmt = self::db()->prepare('DELETE FROM KRON_TASK_CATEGORIES WHERE id = :id');
        $stmt->execute(['id' => $id]);
    }
}
