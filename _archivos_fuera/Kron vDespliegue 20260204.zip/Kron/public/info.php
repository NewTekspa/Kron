<?php
// info.php
phpinfo();
