<?php
// db_check.php
// Página para verificar tablas y estructura de la base de datos

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Verificación de Base de Datos KRON</h1>";

$requiredTables = [
    'KRON_USERS',
    'KRON_ROLES',
    'KRON_USER_ROLES',
    'KRON_USER_RELATIONS',
    'KRON_TEAMS',
    'KRON_TEAM_MEMBERS',
    'KRON_TASK_CLASSIFICATIONS',
    'KRON_TASK_CATEGORIES',
    'KRON_TASKS',
    'KRON_TASK_LOGS',
    'KRON_TASK_TIMES',
];

try {
    $configFile = __DIR__ . '/../config/database.php';
    if (!file_exists($configFile)) {
        throw new Exception("No se encontró el archivo de configuración: $configFile");
    }
    
    $config = require $configFile;
    
    echo "<h2>Configuración de Base de Datos:</h2>";
    echo "<ul>";
    echo "<li><strong>Host:</strong> " . htmlspecialchars($config['host'] ?? 'NO DEFINIDO') . "</li>";
    echo "<li><strong>Database:</strong> " . htmlspecialchars($config['database'] ?? 'NO DEFINIDO') . "</li>";
    echo "<li><strong>Username:</strong> " . htmlspecialchars($config['username'] ?? 'NO DEFINIDO') . "</li>";
    echo "<li><strong>Charset:</strong> " . htmlspecialchars($config['charset'] ?? 'NO DEFINIDO') . "</li>";
    echo "</ul>";
    
    $dsn = "mysql:host={$config['host']};dbname={$config['database']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "<p style='color:green;font-weight:bold;'>✓ Conexión exitosa a la base de datos</p>";
    
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $missing = array_diff($requiredTables, $tables);
    
    echo "<h2>Tablas encontradas (" . count($tables) . " tablas):</h2>";
    echo "<ul>";
    foreach ($tables as $table) {
        $isRequired = in_array($table, $requiredTables);
        $color = $isRequired ? 'green' : 'gray';
        echo "<li style='color:$color;'>" . htmlspecialchars($table) . ($isRequired ? ' ✓' : '') . "</li>";
    }
    echo "</ul>";
    
    if (empty($missing)) {
        echo "<p style='color:green;font-weight:bold;'>✓ Todas las tablas requeridas están presentes!</p>";
    } else {
        echo "<p style='color:red;font-weight:bold;'>✗ Faltan las siguientes tablas:</p><ul>";
        foreach ($missing as $m) {
            echo "<li style='color:red;'>" . htmlspecialchars($m) . "</li>";
        }
        echo "</ul>";
    }
    
    // Verificar algunas tablas importantes
    echo "<h2>Conteo de registros:</h2>";
    echo "<ul>";
    foreach (['KRON_USERS', 'KRON_ROLES', 'KRON_TEAMS', 'KRON_TASKS'] as $table) {
        if (in_array($table, $tables)) {
            $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
            echo "<li><strong>$table:</strong> $count registros</li>";
        }
    }
    echo "</ul>";

    // Mostrar campos y tipos de cada tabla relevante
    echo "<h2>Campos y tipos de cada tabla:</h2>";
    foreach ($requiredTables as $table) {
        if (in_array($table, $tables)) {
            echo "<h3>" . htmlspecialchars($table) . "</h3>";
            $cols = $pdo->query("DESCRIBE $table")->fetchAll(PDO::FETCH_ASSOC);
            echo "<table border='1' cellpadding='4' style='border-collapse:collapse;margin-bottom:16px;'>";
            echo "<tr style='background:#f0f0f0;'><th>Campo</th><th>Tipo</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
            foreach ($cols as $col) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($col['Field']) . "</td>";
                echo "<td>" . htmlspecialchars($col['Type']) . "</td>";
                echo "<td>" . htmlspecialchars($col['Null']) . "</td>";
                echo "<td>" . htmlspecialchars($col['Key']) . "</td>";
                echo "<td>" . htmlspecialchars($col['Default']) . "</td>";
                echo "<td>" . htmlspecialchars($col['Extra']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
    
} catch (PDOException $e) {
    echo "<p style='color:red;font-weight:bold;'>Error de conexión PDO:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
} catch (Exception $e) {
    echo "<p style='color:red;font-weight:bold;'>Error:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}

echo "<hr><p><small>PHP Version: " . PHP_VERSION . "</small></p>";
