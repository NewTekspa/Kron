<?php
ob_start();
?>
<div class="page-header">
    <div>
        <h1 style="display: flex; align-items: center; gap: 12px;">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--blue);">
                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
            </svg>
            Gestor de tareas
        </h1>
        <p class="muted" style="margin: 4px 0 0 44px; font-size: 15px;">Bienvenido, <strong style="color: var(--text-medium);"><?= htmlspecialchars($authUser['nombre'] ?? 'Usuario') ?></strong></p>
    </div>
</div>
<div class="hero-actions" style="margin-bottom: 18px;">
    <button type="button" class="btn" data-open-modal="activityModal">Nueva actividad</button>
</div>

<div class="modal" id="activityModal" data-modal>
    <div class="modal-overlay" data-close-modal></div>
    <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="activityModalTitle">
        <div class="modal-header">
            <h2 id="activityModalTitle">Nueva actividad</h2>
            <button type="button" class="btn btn-secondary btn-small" data-close-modal>Cerrar</button>
        </div>
        <form method="post" action="<?= $basePath ?>/tareas/gestor/crear-actividad" class="form">
            <label>Nombre de la actividad</label>
            <input type="text" name="nombre" required>
            <label>Clasificación</label>
            <select name="clasificacion_id" required>
                <option value="">Selecciona una clasificación</option>
                <?php if (!empty($clasificaciones)): ?>
                    <?php foreach ($clasificaciones as $cl): ?>
                        <option value="<?= (int)$cl['id'] ?>"><?= htmlspecialchars($cl['nombre']) ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
            <label>Equipo responsable</label>
            <select name="team_id" required>
                <option value="">Selecciona un equipo</option>
                <?php if (!empty($equipos)): ?>
                    <?php foreach ($equipos as $team): ?>
                        <option value="<?= (int)$team['id'] ?>"<?= (isset($equipoPorDefecto) && $equipoPorDefecto == $team['id'] ? ' selected' : '') ?>><?= htmlspecialchars($team['nombre']) ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
            <div class="form-actions">
                <button type="submit" class="btn">Crear actividad</button>
            </div>
        </form>
    </div>
</div>

<?php
// Indicadores de tareas - calcular totales basados en todas las tareas del usuario
$totalTareas = $totalPendientes = $totalTerminadas = $totalEnCurso = $totalCriticas = $totalAtrasadas = $totalHoras = 0;
$roleName = \App\Core\Auth::roleName() ?? '';
// Obtener todas las tareas del usuario en todas las actividades
if (!empty($activities)) {
    foreach ($activities as $actividad) {
        if (isset($actividad['id'])) {
            $tareas = \App\Models\Task::allForUserByCategory($authUserId, $roleName, $actividad['id']);
            foreach ($tareas as $t) {
                $totalTareas++;
                switch ($t['estado']) {
                    case 'pendiente': $totalPendientes++; break;
                    case 'terminada': $totalTerminadas++; break;
                    case 'en_curso': $totalEnCurso++; break;
                    case 'atrasada': $totalAtrasadas++; break;
                }
                if (isset($t['prioridad']) && $t['prioridad'] === 'critica') {
                    $totalCriticas++;
                }
                if (isset($t['total_horas'])) {
                    $totalHoras += floatval($t['total_horas']);
                }
            }
        }
    }
}
// Formatear horas a HH:MM
$h = floor($totalHoras);
$m = round(($totalHoras - $h) * 60);
$totalHHMM = sprintf('%02d:%02d', $h, $m);
// Calcular porcentaje de cumplimiento
$cumplimiento = ($totalTareas > 0) ? round(($totalTerminadas / $totalTareas) * 100, 1) : 0;
?>

<style>
.summary-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.summary-card-mini {
    background: white;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    text-align: center;
}
.summary-card-mini h3 {
    margin: 0 0 4px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    color: #64748b;
    letter-spacing: 0.5px;
}
.summary-card-mini .value {
    font-size: 28px;
    font-weight: 700;
    margin: 0;
    color: #1e293b;
}
.summary-card-mini .subtitle {
    margin: 4px 0 0;
    font-size: 11px;
    color: #94a3b8;
}
</style>

<div class="summary-cards">
    <div class="summary-card-mini">
        <h3>Críticas</h3>
        <p class="value"><?= $totalCriticas ?></p>
    </div>
    <div class="summary-card-mini">
        <h3>Tareas</h3>
        <p class="value"><?= $totalTareas ?></p>
    </div>
    <div class="summary-card-mini">
        <h3>Terminadas</h3>
        <p class="value"><?= $totalTerminadas ?></p>
    </div>
    <div class="summary-card-mini">
        <h3>Pendientes</h3>
        <p class="value"><?= $totalPendientes ?></p>
    </div>
    <div class="summary-card-mini">
        <h3>Atrasadas</h3>
        <p class="value"><?= $totalAtrasadas ?></p>
    </div>
    <div class="summary-card-mini">
        <h3>En curso</h3>
        <p class="value"><?= $totalEnCurso ?></p>
    </div>
    <div class="summary-card-mini">
        <h3>Cumplimiento</h3>
        <p class="value"><?= $cumplimiento ?>%</p>
    </div>
</div>

<div class="summary-cards">
    <div class="summary-card-mini">
        <h3>Críticas (H)</h3>
        <p class="value">0.0 h</p>
    </div>
    <div class="summary-card-mini">
        <h3>Tareas (H)</h3>
        <p class="value">0</p>
    </div>
    <div class="summary-card-mini">
        <h3>Terminadas (H)</h3>
        <p class="value">0</p>
    </div>
    <div class="summary-card-mini">
        <h3>Pendientes (H)</h3>
        <p class="value">0</p>
    </div>
    <div class="summary-card-mini">
        <h3>Atrasadas (H)</h3>
        <p class="value">0</p>
    </div>
    <div class="summary-card-mini">
        <h3>En curso (H)</h3>
        <p class="value">0</p>
    </div>
    
</div>

<div class="dashboard-top">
    <div class="dashboard-col" style="flex: 2 1 0; min-width: 900px; max-width: 1200px; margin: 0 auto;">
        <section class="card-block dashboard-card" style="background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); box-shadow: var(--shadow); min-height: 420px;">
            <div class="card-header">
                <div style="display: flex; align-items: flex-start; gap: 12px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                    </div>
                    <div>
                        <h2 style="margin: 0 0 4px;">Mis actividades</h2>
                        <p class="muted" style="margin: 0; font-size: 13px;">📋 Actividades donde participas</p>
                    </div>
                </div>
            </div>
            <div class="table-wrap" style="margin-top: 24px;">
                <table class="table table-compact">
                    <thead>
                        <tr>
                            <th style="min-width:220px;">Actividad</th>
                            <th style="min-width:90px;">Clasificación</th>
                            <th class="table-center" style="min-width:45px;">Total</th>
                            <th class="table-center" style="min-width:45px;">Pend.</th>
                            <th class="table-center" style="min-width:45px;">Term.</th>
                            <th class="table-center" style="min-width:60px;">%</th>
                            <th class="table-center" style="min-width:45px;">Crít.</th>
                            <th class="table-center" style="min-width:45px;">Atr.</th>
                            <th class="table-center" style="min-width:70px;">Horas</th>
                            <th class="table-center" style="min-width:110px;">Estado</th>
                            <th class="table-center" style="min-width:70px;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($activities)): ?>
                            <?php foreach ($activities as $actividad): ?>
                                <?php
                                // Obtener tareas de la actividad
                                $tareas = [];
                                if (isset($actividad['id'])) {
                                    $tareas = \App\Models\Task::allForUserByCategory($authUser['id'], $roleName ?? '', $actividad['id']);
                                }
                                $pendientes = $terminadas = $enCurso = $criticas = $atrasadas = $totalHoras = 0;
                                foreach ($tareas as $t) {
                                    switch ($t['estado']) {
                                        case 'pendiente': $pendientes++; break;
                                        case 'terminada': $terminadas++; break;
                                        case 'en_curso': $enCurso++; break;
                                        case 'atrasada': $atrasadas++; break;
                                    }
                                    if (isset($t['prioridad']) && $t['prioridad'] === 'critica') {
                                        $criticas++;
                                    }
                                    if (isset($t['total_horas'])) {
                                        $totalHoras += floatval($t['total_horas']);
                                    }
                                }
                                $pendientesTotal = $pendientes + $enCurso;
                                $h = floor($totalHoras);
                                $m = round(($totalHoras - $h) * 60);
                                $totalHHMM = sprintf('%02d:%02d', $h, $m);
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($actividad['nombre']) ?></td>
                                    <td><?= htmlspecialchars($actividad['clasificacion_nombre'] ?? '-') ?></td>
                                    <td class="table-center"><?= (int)$actividad['total_tareas'] ?></td>
                                    <td class="table-center"><?= $pendientesTotal ?></td>
                                    <td class="table-center"><?= $terminadas ?></td>
                                    <td class="table-center">
                                        <?php
                                        $porcentaje = ($actividad['total_tareas'] > 0) ? round(($terminadas / $actividad['total_tareas']) * 100) : 0;
                                        ?>
                                        <?= $porcentaje ?>%
                                    </td>
                                    <td class="table-center"><?= $criticas ?></td>
                                    <td class="table-center"><?= $atrasadas ?></td>
                                    <td class="table-center"><?= $totalHHMM ?> h</td>
                                    <td class="table-center">
                                        <?= htmlspecialchars($actividad['estado_actividad'] ?? '-') ?>
                                    </td>
                                    <td class="table-center">
                                        <a href="<?= $basePath ?>/tareas/actividad?category_id=<?= (int)$actividad['id'] ?>" class="btn btn-small btn-icon" title="Ver tareas" aria-label="Ver tareas">
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <rect x="3" y="4" width="18" height="16" rx="2"/>
                                                <line x1="8" y1="8" x2="16" y2="8"/>
                                                <line x1="8" y1="12" x2="16" y2="12"/>
                                                <line x1="8" y1="16" x2="16" y2="16"/>
                                            </svg>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" class="muted">No tienes actividades asignadas.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>
<?php
$content = ob_get_clean();
require __DIR__ . '/../layouts/main.php';
