<?php
/**
 * Script para crear todas las tablas del sistema KRON en el servidor web.
 * Ejecuta una sola vez y elimina este archivo por seguridad.
 */

// Cargar configuración de base de datos
$dbConfig = require __DIR__ . '/../config/database.php';

header('Content-Type: text/plain; charset=utf-8');

try {
    $db = new PDO(
        "mysql:host={$dbConfig['host']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}",
        $dbConfig['username'],
        $dbConfig['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "Conectado a la base de datos.\n\n";

    // SQL de creación de tablas
    $sql = file_get_contents(__DIR__ . '/../Temp/docs/001_schema.sql');
    $stmts = array_filter(array_map('trim', explode(';', $sql)));
    $ok = 0;
    foreach ($stmts as $stmt) {
        if ($stmt) {
            $db->exec($stmt);
            $ok++;
        }
    }
    echo "✓ Tablas creadas correctamente ($ok sentencias ejecutadas)\n";
    echo "\nIMPORTANTE: Elimina este archivo (install_db.php) por seguridad.\n";
} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "\nDetalles:\n";
    echo $e->getTraceAsString() . "\n";
}
?>