<?php
/**
 * Script de actualización de base de datos
 * Ejecutar SOLO UNA VEZ en: https://www.newtek.cl/kron/public/update_db.php
 * DESPUÉS DE EJECUTAR, ELIMINAR ESTE ARCHIVO POR SEGURIDAD
 */


// Cargar configuración de base de datos directamente
$dbConfig = require __DIR__ . '/../config/database.php';

header('Content-Type: text/plain; charset=utf-8');

echo "=== ACTUALIZACIÓN DE BASE DE DATOS ===\n\n";

// Contraseña de seguridad (cámbiala antes de subir)
$securityKey = isset($_GET['key']) ? $_GET['key'] : '';
if ($securityKey !== 'kron2026update') {
    die("ERROR: Clave de seguridad incorrecta. Usa ?key=kron2026update\n");
}

try {

    $db = new PDO(
        "mysql:host={$dbConfig['host']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}",
        $dbConfig['username'],
        $dbConfig['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    echo "Conectado a la base de datos.\n\n";

    // Verificar columnas de KRON_TASKS
    $stmt = $db->query("DESCRIBE KRON_TASKS");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "Columnas actuales: " . implode(', ', $columns) . "\n\n";
    
    // PASO 1: Renombrar asignado_a a user_id si existe
    if (in_array('asignado_a', $columns) && !in_array('user_id', $columns)) {
        echo "Renombrando columna asignado_a a user_id...\n";
        $db->exec("ALTER TABLE KRON_TASKS CHANGE COLUMN asignado_a user_id BIGINT UNSIGNED NOT NULL");
        echo "✓ Columna renombrada: asignado_a → user_id\n";
        
        // Actualizar la lista de columnas
        $stmt = $db->query("DESCRIBE KRON_TASKS");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } else if (in_array('user_id', $columns)) {
        echo "✓ La columna user_id ya existe\n";
    }
    
    // PASO 2: Agregar columna fecha_compromiso si no existe
    if (!in_array('fecha_compromiso', $columns)) {
        echo "Agregando columna fecha_compromiso...\n";
        $db->exec("ALTER TABLE KRON_TASKS ADD COLUMN fecha_compromiso DATE NULL AFTER titulo");
        echo "✓ Columna fecha_compromiso agregada\n";
    } else {
        echo "✓ La columna fecha_compromiso ya existe\n";
    }
    
    // PASO 3: Agregar columna fecha_termino_real si no existe
    if (!in_array('fecha_termino_real', $columns)) {
        echo "Agregando columna fecha_termino_real...\n";
        $db->exec("ALTER TABLE KRON_TASKS ADD COLUMN fecha_termino_real DATE NULL AFTER fecha_compromiso");
        echo "✓ Columna fecha_termino_real agregada\n";
    } else {
        echo "✓ La columna fecha_termino_real ya existe\n";
    }
    
    echo "\n=== ACTUALIZACIÓN COMPLETADA ===\n";
    echo "\n⚠️  IMPORTANTE: Elimina este archivo (update_db.php) por seguridad.\n";
    
} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "\nDetalles:\n";
    echo $e->getTraceAsString() . "\n";
}

?>
<?php
/**
 * Script de actualización de base de datos
 * Ejecutar SOLO UNA VEZ en: https://www.newtek.cl/kron/public/update_db.php
 * DESPUÉS DE EJECUTAR, ELIMINAR ESTE ARCHIVO POR SEGURIDAD
 */


// Cargar configuración de base de datos directamente
$dbConfig = require __DIR__ . '/../config/database.php';

header('Content-Type: text/plain; charset=utf-8');

echo "=== ACTUALIZACIÓN DE BASE DE DATOS ===\n\n";

// Contraseña de seguridad (cámbiala antes de subir)
$securityKey = isset($_GET['key']) ? $_GET['key'] : '';
if ($securityKey !== 'kron2026update') {
    die("ERROR: Clave de seguridad incorrecta. Usa ?key=kron2026update\n");
}

try {

    $db = new PDO(
        "mysql:host={$dbConfig['host']};dbname={$dbConfig['database']};charset={$dbConfig['charset']}",
        $dbConfig['username'],
        $dbConfig['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    echo "Conectado a la base de datos.\n\n";

    // Verificar columnas de KRON_TASKS
    $stmt = $db->query("DESCRIBE KRON_TASKS");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "Columnas actuales: " . implode(', ', $columns) . "\n\n";
    
    // PASO 1: Renombrar asignado_a a user_id si existe
    if (in_array('asignado_a', $columns) && !in_array('user_id', $columns)) {
        echo "Renombrando columna asignado_a a user_id...\n";
        $db->exec("ALTER TABLE KRON_TASKS CHANGE COLUMN asignado_a user_id BIGINT UNSIGNED NOT NULL");
        echo "✓ Columna renombrada: asignado_a → user_id\n";
        
        // Actualizar la lista de columnas
        $stmt = $db->query("DESCRIBE KRON_TASKS");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } else if (in_array('user_id', $columns)) {
        echo "✓ La columna user_id ya existe\n";
    }
    
    // PASO 2: Agregar columna fecha_compromiso si no existe
    if (!in_array('fecha_compromiso', $columns)) {
        echo "Agregando columna fecha_compromiso...\n";
        $db->exec("ALTER TABLE KRON_TASKS ADD COLUMN fecha_compromiso DATE NULL AFTER titulo");
        echo "✓ Columna fecha_compromiso agregada\n";
    } else {
        echo "✓ La columna fecha_compromiso ya existe\n";
    }
    
    // PASO 3: Agregar columna fecha_termino_real si no existe
    if (!in_array('fecha_termino_real', $columns)) {
        echo "Agregando columna fecha_termino_real...\n";
        $db->exec("ALTER TABLE KRON_TASKS ADD COLUMN fecha_termino_real DATE NULL AFTER fecha_compromiso");
        echo "✓ Columna fecha_termino_real agregada\n";
    } else {
        echo "✓ La columna fecha_termino_real ya existe\n";
    }
    
    echo "\n=== ACTUALIZACIÓN COMPLETADA ===\n";
    echo "\n⚠️  IMPORTANTE: Elimina este archivo (update_db.php) por seguridad.\n";
    
} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "\nDetalles:\n";
    echo $e->getTraceAsString() . "\n";
}
