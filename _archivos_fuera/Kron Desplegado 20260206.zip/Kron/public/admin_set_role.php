<?php
// admin_set_role.php
// Página rápida para asignar el rol de administrador a un usuario existente
require_once __DIR__ . '/../config/database.php';

$config = require __DIR__ . '/../config/database.php';
function getPdo($config) {
    $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset={$config['charset']}";
    return new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    if ($email) {
        try {
            $pdo = getPdo($config);
            $userId = $pdo->prepare("SELECT id FROM KRON_USERS WHERE email = ?");
            $userId->execute([$email]);
            $userId = $userId->fetchColumn();
            if ($userId) {
                $roleId = $pdo->query("SELECT id FROM KRON_ROLES WHERE nombre='administrador'")->fetchColumn();
                if ($roleId) {
                    // Verifica si ya tiene el rol
                    $exists = $pdo->prepare("SELECT 1 FROM KRON_USER_ROLES WHERE user_id=? AND role_id=?");
                    $exists->execute([$userId, $roleId]);
                    if (!$exists->fetchColumn()) {
                        $pdo->prepare("INSERT INTO KRON_USER_ROLES (user_id, role_id) VALUES (?, ?)")->execute([$userId, $roleId]);
                        $msg = 'Rol de administrador asignado correctamente.';
                    } else {
                        $msg = 'El usuario ya tiene el rol de administrador.';
                    }
                } else {
                    $msg = 'No se encontró el rol administrador.';
                }
            } else {
                $msg = 'No se encontró el usuario con ese email.';
            }
        } catch (Exception $e) {
            $msg = 'Error: ' . $e->getMessage();
        }
    } else {
        $msg = 'Ingresa el email del usuario.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Asignar rol administrador</title>
    <style>body{font-family:sans-serif;margin:2em;}form{max-width:400px;}input{width:100%;margin-bottom:1em;}</style>
</head>
<body>
    <h2>Asignar rol de administrador</h2>
    <?php if ($msg) echo '<p><b>' . htmlspecialchars($msg) . '</b></p>'; ?>
    <form method="post">
        <label>Email del usuario:<br><input type="email" name="email" required></label><br>
        <button type="submit">Asignar rol</button>
    </form>
    <p style="color:red">¡Recuerda borrar este archivo después de usarlo!</p>
</body>
</html>
