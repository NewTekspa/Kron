<?php
// admin_reset.php
// Página para crear un usuario administrador manualmente

// Configuración DB (ajusta si es necesario)

$config = require __DIR__ . '/../config/database.php';
function getPdo($config) {
    $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset={$config['charset']}";
    return new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $nombre = trim($_POST['nombre'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($email && $nombre && $password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        try {
            $pdo = getPdo($config);
            // Insertar usuario
            $pdo->prepare("INSERT INTO KRON_USERS (nombre, email, estado, fecha_ingreso, password_hash) VALUES (?, ?, 'activo', CURDATE(), ?)")
                ->execute([$nombre, $email, $hash]);
            $userId = $pdo->lastInsertId();
            // Obtener id rol admin
            $roleId = $pdo->query("SELECT id FROM KRON_ROLES WHERE nombre='administrador'")->fetchColumn();
            if ($roleId) {
                $pdo->prepare("INSERT INTO KRON_USER_ROLES (user_id, role_id) VALUES (?, ?)")->execute([$userId, $roleId]);
            }
            $msg = 'Usuario administrador creado correctamente.';
        } catch (Exception $e) {
            $msg = 'Error: ' . $e->getMessage();
        }
    } else {
        $msg = 'Completa todos los campos.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Administrador KRON</title>
    <style>body{font-family:sans-serif;margin:2em;}form{max-width:400px;}input{width:100%;margin-bottom:1em;}</style>
</head>
<body>
    <h2>Crear usuario administrador</h2>
    <?php if ($msg) echo '<p><b>' . htmlspecialchars($msg) . '</b></p>'; ?>
    <form method="post">
        <label>Nombre:<br><input type="text" name="nombre" required></label><br>
        <label>Email:<br><input type="email" name="email" required></label><br>
        <label>Contraseña:<br><input type="password" name="password" required></label><br>
        <button type="submit">Crear administrador</button>
    </form>
    <p style="color:red">¡Recuerda borrar este archivo después de usarlo!</p>
</body>
</html>
