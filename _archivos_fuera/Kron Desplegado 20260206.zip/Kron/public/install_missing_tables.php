<?php
// install_missing_tables.php
// Script para crear automáticamente las tablas faltantes en la base de datos

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Instalador de Tablas KRON</h1>";

$sqlStatements = [
    'KRON_USERS' => "CREATE TABLE KRON_USERS (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'activo',
    fecha_ingreso DATE NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_ROLES' => "CREATE TABLE KRON_ROLES (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(255) NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_roles_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_USER_ROLES' => "CREATE TABLE KRON_USER_ROLES (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    role_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_user_roles (user_id, role_id),
    CONSTRAINT fk_kron_user_roles_user
        FOREIGN KEY (user_id) REFERENCES KRON_USERS(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_kron_user_roles_role
        FOREIGN KEY (role_id) REFERENCES KRON_ROLES(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_USER_RELATIONS' => "CREATE TABLE KRON_USER_RELATIONS (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    supervisor_id BIGINT UNSIGNED NOT NULL,
    subordinado_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_user_rel (supervisor_id, subordinado_id),
    UNIQUE KEY uk_kron_user_rel_subordinado (subordinado_id),
    CONSTRAINT fk_kron_user_rel_supervisor
        FOREIGN KEY (supervisor_id) REFERENCES KRON_USERS(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_kron_user_rel_subordinado
        FOREIGN KEY (subordinado_id) REFERENCES KRON_USERS(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_TEAMS' => "CREATE TABLE KRON_TEAMS (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(120) NOT NULL,
    subgerente_id BIGINT UNSIGNED NOT NULL,
    jefe_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_teams_nombre (nombre),
    CONSTRAINT fk_kron_teams_subgerente
        FOREIGN KEY (subgerente_id) REFERENCES KRON_USERS(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_kron_teams_jefe
        FOREIGN KEY (jefe_id) REFERENCES KRON_USERS(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_TEAM_MEMBERS' => "CREATE TABLE KRON_TEAM_MEMBERS (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    team_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_team_members_user (user_id),
    KEY idx_kron_team_members_team (team_id),
    CONSTRAINT fk_kron_team_members_team
        FOREIGN KEY (team_id) REFERENCES KRON_TEAMS(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_kron_team_members_user
        FOREIGN KEY (user_id) REFERENCES KRON_USERS(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_TASK_CLASSIFICATIONS' => "CREATE TABLE KRON_TASK_CLASSIFICATIONS (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(120) NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_task_classifications_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_TASK_CATEGORIES' => "CREATE TABLE KRON_TASK_CATEGORIES (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(190) NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    classification_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_task_categories_nombre (nombre),
    KEY idx_kron_task_categories_classification (classification_id),
    CONSTRAINT fk_kron_task_categories_created_by
        FOREIGN KEY (created_by) REFERENCES KRON_USERS(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_kron_task_categories_classification
        FOREIGN KEY (classification_id) REFERENCES KRON_TASK_CLASSIFICATIONS(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_TASKS' => "CREATE TABLE KRON_TASKS (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    category_id BIGINT UNSIGNED NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    fecha_compromiso DATE NULL,
    fecha_termino_real DATE NULL,
    prioridad VARCHAR(20) NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'pendiente',
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_kron_tasks_category (category_id),
    KEY idx_kron_tasks_user (user_id),
    KEY idx_kron_tasks_created_by (created_by),
    CONSTRAINT fk_kron_tasks_category
        FOREIGN KEY (category_id) REFERENCES KRON_TASK_CATEGORIES(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_kron_tasks_user
        FOREIGN KEY (user_id) REFERENCES KRON_USERS(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_kron_tasks_created_by
        FOREIGN KEY (created_by) REFERENCES KRON_USERS(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_TASK_LOGS' => "CREATE TABLE KRON_TASK_LOGS (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    task_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    contenido TEXT NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_kron_task_logs_task (task_id),
    CONSTRAINT fk_kron_task_logs_task
        FOREIGN KEY (task_id) REFERENCES KRON_TASKS(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_kron_task_logs_user
        FOREIGN KEY (user_id) REFERENCES KRON_USERS(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'KRON_TASK_TIMES' => "CREATE TABLE KRON_TASK_TIMES (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    task_id BIGINT UNSIGNED NOT NULL,
    fecha DATE NOT NULL,
    horas DECIMAL(5,2) NOT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_kron_task_times (task_id, fecha),
    CONSTRAINT fk_kron_task_times_task
        FOREIGN KEY (task_id) REFERENCES KRON_TASKS(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];

try {
    $configFile = __DIR__ . '/../config/database.php';
    if (!file_exists($configFile)) {
        throw new Exception("No se encontró el archivo de configuración: $configFile");
    }
    
    $config = require $configFile;
    $dsn = "mysql:host={$config['host']};dbname={$config['database']};charset={$config['charset']}";
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "<p style='color:green;'>✓ Conexión exitosa a la base de datos</p>";
    
    $existingTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $created = 0;
    $skipped = 0;
    $errors = [];
    
    echo "<h2>Resultado de la instalación:</h2>";
    echo "<ul>";
    
    foreach ($sqlStatements as $tableName => $sql) {
        if (in_array($tableName, $existingTables)) {
            echo "<li style='color:gray;'>⊙ <strong>$tableName</strong>: Ya existe (omitida)</li>";
            $skipped++;
        } else {
            try {
                $pdo->exec($sql);
                echo "<li style='color:green;'>✓ <strong>$tableName</strong>: Creada exitosamente</li>";
                $created++;
            } catch (PDOException $e) {
                echo "<li style='color:red;'>✗ <strong>$tableName</strong>: Error al crear</li>";
                $errors[] = "$tableName: " . $e->getMessage();
            }
        }
    }
    
    echo "</ul>";
    
    echo "<h3>Resumen:</h3>";
    echo "<ul>";
    echo "<li><strong>Tablas creadas:</strong> $created</li>";
    echo "<li><strong>Tablas omitidas (ya existían):</strong> $skipped</li>";
    echo "<li><strong>Errores:</strong> " . count($errors) . "</li>";
    echo "</ul>";
    
    if (!empty($errors)) {
        echo "<h3 style='color:red;'>Detalles de errores:</h3>";
        echo "<pre>" . htmlspecialchars(implode("\n", $errors)) . "</pre>";
    }
    
    if ($created > 0) {
        echo "<p style='color:green;font-weight:bold;'>✓ Instalación completada. Se crearon $created tablas.</p>";
    } else if (count($errors) === 0) {
        echo "<p style='color:blue;font-weight:bold;'>⊙ Todas las tablas ya existen. No se creó ninguna tabla nueva.</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color:red;font-weight:bold;'>Error de conexión PDO:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
} catch (Exception $e) {
    echo "<p style='color:red;font-weight:bold;'>Error:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}

echo "<hr>";
echo "<p><a href='db_check.php'>Ver estado de la base de datos</a></p>";
