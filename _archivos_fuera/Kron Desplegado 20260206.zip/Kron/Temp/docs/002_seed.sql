-- Datos iniciales KRON (roles y admin)

INSERT INTO KRON_ROLES (nombre, descripcion) VALUES
('administrador', 'Gestion total del sistema'),
('colaborador', 'Acceso a sus propios datos'),
('jefe', 'Acceso a datos de su equipo'),
('subgerente', 'Acceso total a su area');

INSERT INTO KRON_USERS (nombre, email, estado, fecha_ingreso, password_hash)
VALUES ('Jose Barrios', 'administrador@gmail.com', 'activo', CURDATE(), '$2y$12$/Xm7.gZy43agmFG1IlZE6uvLE7VJ237wdBLSfaYTb9Je5lmKVfkdi');

INSERT INTO KRON_USER_ROLES (user_id, role_id)
SELECT u.id, r.id
FROM KRON_USERS u
JOIN KRON_ROLES r ON r.nombre = 'administrador'
WHERE u.email = 'administrador@gmail.com';
