<?php

return [
    'name' => 'KRON',
    'env' => 'local',
    'debug' => true,
    'url' => 'https://www.newtek.cl/kron',
    'base_path' => '/kron', // Ajustado para despliegue en subdirectorio
];
