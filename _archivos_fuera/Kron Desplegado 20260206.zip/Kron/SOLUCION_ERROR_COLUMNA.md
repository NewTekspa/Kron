# Solución al Error de Columna user_id

## Problema Detectado

```
Fatal error: SQLSTATE[42S22]: Column not found: 1054 Unknown column 't.user_id' in 'WHERE'
```

La base de datos en producción tiene un **esquema antiguo** donde la columna se llama `asignado_a` en lugar de `user_id`.

## Solución Rápida (Recomendada)

### Opción 1: Script Automático

1. Accede a: `https://www.newtek.cl/kron/public/update_db.php?key=kron2026update`
2. Verifica que aparezca: `✓ Columna renombrada: asignado_a → user_id`
3. **IMPORTANTE**: Después de ejecutar, elimina el archivo `update_db.php` por seguridad

### Opción 2: SQL Manual

Ejecuta este comando SQL directamente en tu base de datos (phpMyAdmin, etc.):

```sql
ALTER TABLE KRON_TASKS CHANGE COLUMN asignado_a user_id BIGINT UNSIGNED NOT NULL;
```

## Verificación

Después de aplicar la solución:

1. Accede a: `https://www.newtek.cl/kron/public/check_db.php`
2. Verifica que aparezca: `✓ Todas las columnas requeridas están presentes`
3. Intenta acceder nuevamente a la aplicación

## Archivos Actualizados

- ✅ [public/update_db.php](public/update_db.php) - Ahora detecta y renombra la columna automáticamente
- ✅ [public/check_db.php](public/check_db.php) - Ahora detecta si existe la columna antigua y muestra advertencia

## ¿Por qué ocurrió esto?

El código actual usa el nombre estándar `user_id` en todas las consultas SQL, pero la base de datos en producción tiene el nombre antiguo `asignado_a`. Al renombrar la columna, toda la aplicación funcionará correctamente.

## Siguiente Paso

Una vez solucionado, **elimina estos archivos por seguridad**:
- `public/update_db.php`
- `public/check_db.php`
- Este archivo (`SOLUCION_ERROR_COLUMNA.md`)
